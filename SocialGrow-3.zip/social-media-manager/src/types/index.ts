export type Platform =
  | "instagram"
  | "twitter"
  | "linkedin"
  | "tiktok"
  | "youtube"
  | "telegram"
  | "eitaa"
  | "bale";

export type PostStatus = "draft" | "scheduled" | "published" | "failed";

export interface SocialAccount {
  id: string;
  platform: Platform;
  username: string;
  displayName: string;
  avatarUrl: string;
  followers: number;
  connected: boolean;
  lastSync: string;
  accessToken?: string;
}

export interface MediaItem {
  id: string;
  type: "image" | "video";
  url: string;
  thumbnail?: string;
}

export interface Post {
  id: string;
  content: string;
  platforms: Platform[];
  accounts: string[];
  media: MediaItem[];
  status: PostStatus;
  scheduledAt: string | null;
  publishedAt: string | null;
  createdAt: string;
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
    views?: number;
  };
}

export interface Comment {
  id: string;
  platform: Platform;
  postId: string;
  author: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
  replied: boolean;
  replyContent?: string;
}

export interface AnalyticsOverview {
  totalFollowers: number;
  followerGrowth: number;
  totalEngagement: number;
  engagementRate: number;
  postsThisWeek: number;
  bestPerformingPost: string;
}

export interface PlatformStats {
  platform: Platform;
  followers: number;
  engagementRate: number;
  posts: number;
  growth: number;
}
