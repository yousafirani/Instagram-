/**
 * Worker برای انتشار پست‌های زمان‌بندی شده
 * اجرا: npx tsx src/workers/post-publisher.ts
 * یا: npm run worker
 */

import { startPostWorker } from "../lib/queue";

console.log("🚀 SocialGrow Post Publisher Worker started...");
console.log("Waiting for scheduled jobs on Redis...");

const worker = startPostWorker();

process.on("SIGINT", async () => {
  console.log("Shutting down worker...");
  await worker.close();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await worker.close();
  process.exit(0);
});
