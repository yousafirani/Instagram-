/**
 * صف انتشار
 * - اگر Redis باشد از BullMQ استفاده می‌شود
 * - اگر نباشد، پست در دیتابیس می‌ماند و Cron آن را منتشر می‌کند (مناسب موبایل/Vercel)
 */

export interface ScheduledPostJob {
  postId: string;
  content: string;
  platforms: string[];
  accountIds: string[];
  mediaUrls?: string[];
  accessTokens?: Record<string, string>;
}

let redisAvailable: boolean | null = null;

async function tryQueue() {
  if (redisAvailable === false) return null;
  try {
    const { Queue } = await import("bullmq");
    const IORedis = (await import("ioredis")).default;
    const connection = new IORedis(process.env.REDIS_URL || "redis://localhost:6379", {
      maxRetriesPerRequest: null,
      connectTimeout: 3000,
      lazyConnect: true,
    });
    await connection.connect();
    redisAvailable = true;
    return new Queue("social-posts", { connection });
  } catch {
    redisAvailable = false;
    return null;
  }
}

export async function schedulePost(data: ScheduledPostJob, scheduledAt: Date) {
  const delay = Math.max(0, scheduledAt.getTime() - Date.now());
  const queue = await tryQueue();
  if (!queue) {
    return {
      id: `db_${data.postId}`,
      mode: "database" as const,
      message: "بدون Redis — انتشار با Cron از روی دیتابیس",
    };
  }
  const job = await queue.add("publish-post", data, {
    delay,
    attempts: 3,
    backoff: { type: "exponential", delay: 5000 },
  });
  return { id: job.id, mode: "redis" as const };
}

export async function publishNow(data: ScheduledPostJob) {
  const queue = await tryQueue();
  if (!queue) {
    return {
      id: `now_${data.postId}`,
      mode: "database" as const,
      message: "بدون Redis — در دیتابیس ثبت شد",
    };
  }
  const job = await queue.add("publish-post", data, {
    attempts: 3,
    backoff: { type: "exponential", delay: 5000 },
  });
  return { id: job.id, mode: "redis" as const };
}
