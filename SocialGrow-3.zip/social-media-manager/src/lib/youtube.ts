/**
 * اسکلت YouTube Data API v3
 *
 * پیش‌نیاز:
 * 1. پروژه در Google Cloud Console
 * 2. فعال‌سازی YouTube Data API v3
 * 3. OAuth 2.0 Client ID (برای آپلود و مدیریت)
 * 4. یا API Key برای خواندن عمومی
 *
 * مستندات: https://developers.google.com/youtube/v3
 */

const YT_API = "https://www.googleapis.com/youtube/v3";

export interface YouTubeChannel {
  id: string;
  title: string;
  description: string;
  customUrl?: string;
  subscriberCount: number;
  videoCount: number;
  viewCount: number;
  thumbnailUrl?: string;
}

export interface YouTubeVideoStats {
  id: string;
  title: string;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  publishedAt: string;
}

/**
 * دریافت اطلاعات کانال
 */
export async function getChannelInfo(
  accessToken: string,
  channelId?: string
): Promise<YouTubeChannel> {
  const mine = channelId ? "" : "&mine=true";
  const idParam = channelId ? `&id=${channelId}` : "";
  const url = `${YT_API}/channels?part=snippet,statistics${mine}${idParam}`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`YouTube API error: ${await res.text()}`);

  const data = await res.json();
  const item = data.items?.[0];
  if (!item) throw new Error("Channel not found");

  return {
    id: item.id,
    title: item.snippet.title,
    description: item.snippet.description,
    customUrl: item.snippet.customUrl,
    subscriberCount: Number(item.statistics.subscriberCount || 0),
    videoCount: Number(item.statistics.videoCount || 0),
    viewCount: Number(item.statistics.viewCount || 0),
    thumbnailUrl: item.snippet.thumbnails?.default?.url,
  };
}

/**
 * لیست ویدیوهای کانال (آخرین)
 */
export async function listRecentVideos(
  accessToken: string,
  channelId: string,
  maxResults = 10
): Promise<YouTubeVideoStats[]> {
  // ابتدا uploads playlist را پیدا می‌کنیم
  const chRes = await fetch(
    `${YT_API}/channels?part=contentDetails&id=${channelId}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!chRes.ok) throw new Error(await chRes.text());
  const chData = await chRes.json();
  const uploadsId = chData.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploadsId) return [];

  const plRes = await fetch(
    `${YT_API}/playlistItems?part=snippet,contentDetails&playlistId=${uploadsId}&maxResults=${maxResults}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!plRes.ok) throw new Error(await plRes.text());
  const plData = await plRes.json();

  const videoIds = (plData.items || [])
    .map((i: any) => i.contentDetails?.videoId)
    .filter(Boolean)
    .join(",");

  if (!videoIds) return [];

  const statsRes = await fetch(
    `${YT_API}/videos?part=snippet,statistics&id=${videoIds}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!statsRes.ok) throw new Error(await statsRes.text());
  const statsData = await statsRes.json();

  return (statsData.items || []).map((v: any) => ({
    id: v.id,
    title: v.snippet.title,
    viewCount: Number(v.statistics.viewCount || 0),
    likeCount: Number(v.statistics.likeCount || 0),
    commentCount: Number(v.statistics.commentCount || 0),
    publishedAt: v.snippet.publishedAt,
  }));
}

/**
 * پاسخ به کامنت یوتیوب
 */
export async function replyToYouTubeComment(
  accessToken: string,
  parentId: string,
  text: string
) {
  const res = await fetch(`${YT_API}/comments?part=snippet`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      snippet: {
        parentId,
        textOriginal: text,
      },
    }),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

/**
 * نکته: آپلود ویدیو نیاز به resumable upload دارد و از این API ساده خارج است.
 * برای آپلود از Google API Client Libraries یا endpoint
 * https://www.googleapis.com/upload/youtube/v3/videos استفاده کنید.
 */
EOF