/** بانک هشتگ آماده برای ذخیره و استفاده سریع */

export interface HashtagPack {
  id: string;
  name: string;
  tags: string[];
  category: string;
}

export const DEFAULT_HASHTAG_PACKS: HashtagPack[] = [
  {
    id: "edu",
    name: "آموزشی",
    category: "محتوا",
    tags: ["#آموزش", "#نکات", "#یادگیری", "#مهارت", "#رشد_فردی"],
  },
  {
    id: "business",
    name: "کسب‌وکار",
    category: "بیزنس",
    tags: ["#کسب_و_کار", "#کارآفرینی", "#استارتاپ", "#فروش", "#برندینگ"],
  },
  {
    id: "reels",
    name: "ریلز وایرال",
    category: "فرمت",
    tags: ["#ریلز", "#ویدیو_کوتاه", "#ترند", "#اکسپلور", "#محتوا"],
  },
  {
    id: "engage",
    name: "تعاملی",
    category: "رشد",
    tags: ["#نظر_شما", "#سؤال", "#گفتگو", "#کامنت", "#انجمن"],
  },
  {
    id: "local_fa",
    name: "فارسی / ایران",
    category: "محلی",
    tags: ["#ایران", "#تهران", "#فارسی", "#محتوای_فارسی"],
  },
];

let customPacks: HashtagPack[] = [];

export function listHashtagPacks(): HashtagPack[] {
  return [...DEFAULT_HASHTAG_PACKS, ...customPacks];
}

export function addHashtagPack(pack: Omit<HashtagPack, "id">): HashtagPack {
  const created = { ...pack, id: `custom_${Date.now()}` };
  customPacks.push(created);
  return created;
}
