/**
 * قوانین اتوماسیون مجاز:
 * - پاسخ خودکار فقط به کامنت‌های زیر پست‌های خودتان
 * - با تأخیر و محدودیت نرخ (ضد اسپم)
 * - قابل خاموش کردن از تنظیمات
 * - هشتگ و کپشن پیشنهادی برای پست خودتان
 */

import { suggestCommentReply } from "./ai";
import { suggestHashtagsForText } from "./content-templates";

export interface AutomationSettings {
  autoReplyComments: boolean;
  autoReplyDelayMinutes: number; // تأخیر قبل از پاسخ (طبیعی‌تر)
  autoReplyOnlyQuestions: boolean; // فقط اگر کامنت سؤال باشد
  autoHashtags: boolean;
  autoBestTime: boolean;
  maxAutoRepliesPerHour: number;
}

export const DEFAULT_AUTOMATION: AutomationSettings = {
  autoReplyComments: false, // پیش‌فرض خاموش – کاربر باید فعال کند
  autoReplyDelayMinutes: 15,
  autoReplyOnlyQuestions: true,
  autoHashtags: true,
  autoBestTime: true,
  maxAutoRepliesPerHour: 10,
};

const QUESTION_MARKERS = ["?", "؟", "چی", "چطور", "چگونه", "کی", "کجا", "آیا", "میشه", "میشه‌", "لطفا"];

export function looksLikeQuestion(text: string): boolean {
  const t = text.trim();
  if (t.includes("?") || t.includes("؟")) return true;
  return QUESTION_MARKERS.some((m) => t.includes(m));
}

export async function generateAutoReply(
  comment: string,
  postContent: string,
  platform: string,
  settings: AutomationSettings
): Promise<string | null> {
  if (!settings.autoReplyComments) return null;
  if (settings.autoReplyOnlyQuestions && !looksLikeQuestion(comment)) {
    return null;
  }

  const reply = await suggestCommentReply({
    comment,
    postContent,
    platform,
    brandTone: "friendly",
    language: "fa",
  });

  return reply;
}

export function enhanceCaption(
  caption: string,
  options: { autoHashtags?: boolean; templateHashtags?: string[] }
): { caption: string; hashtags: string[] } {
  let hashtags: string[] = [];

  if (options.autoHashtags !== false) {
    hashtags = suggestHashtagsForText(caption);
    if (options.templateHashtags?.length) {
      hashtags = [...new Set([...options.templateHashtags, ...hashtags])].slice(0, 10);
    }
  }

  // اگر کپشن هنوز هشتگ ندارد، اضافه می‌کنیم
  const hasHashtagInText = /#\S+/.test(caption);
  let finalCaption = caption.trim();
  if (!hasHashtagInText && hashtags.length > 0) {
    finalCaption = `${finalCaption}\n\n${hashtags.join(" ")}`;
  }

  return { caption: finalCaption, hashtags };
}

export function suggestBestTimes(platforms: string[]): string[] {
  const map: Record<string, string[]> = {
    instagram: ["۱۲:۰۰–۱۴:۰۰", "۱۹:۰۰–۲۱:۰۰"],
    twitter: ["۱۲:۰۰–۱۴:۰۰", "۲۰:۰۰–۲۲:۰۰"],
    linkedin: ["۰۸:۰۰–۱۰:۰۰", "۱۷:۰۰–۱۸:۰۰"],
    tiktok: ["۱۹:۰۰–۲۳:۰۰"],
    youtube: ["۱۴:۰۰–۱۶:۰۰", "۲۰:۰۰–۲۲:۰۰"],
  };

  const times = new Set<string>();
  for (const p of platforms) {
    (map[p] || map.instagram).forEach((t) => times.add(t));
  }
  return Array.from(times).slice(0, 4);
}

/** ذخیره ساده تنظیمات در حافظه (در پروداکشن از دیتابیس/Redis) */
let currentSettings: AutomationSettings = { ...DEFAULT_AUTOMATION };

export function getAutomationSettings(): AutomationSettings {
  return { ...currentSettings };
}

export function updateAutomationSettings(
  partial: Partial<AutomationSettings>
): AutomationSettings {
  currentSettings = { ...currentSettings, ...partial };
  return { ...currentSettings };
}
