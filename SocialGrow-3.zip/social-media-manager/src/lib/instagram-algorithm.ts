/**
 * امتیازدهی محتوا بر اساس سیگنال‌های الگوریتم اینستاگرام (۲۰۲۶)
 * منبع: اظهارات Adam Mosseri + ساختار جداگانه Feed / Reels / Stories / Explore
 * این ماژول فقط راهنما و امتیاز است — دایرکت انبوه انجام نمی‌دهد.
 */

export type IgSurface = "feed" | "reels" | "stories" | "explore";

export interface AlgorithmInput {
  caption: string;
  hasVideo: boolean;
  hasCarousel: boolean;
  estimatedDurationSec?: number; // برای ریلز
  hasQuestionCTA: boolean;
  hasSaveableValue: boolean; // آموزشی، چک‌لیست، نکات
  hasHookInFirstLines: boolean;
  platforms?: string[];
}

export interface SignalScore {
  name: string;
  nameFa: string;
  score: number; // 0–100
  weight: number;
  tip: string;
}

export interface AlgorithmReport {
  surface: IgSurface;
  totalScore: number;
  grade: "A" | "B" | "C" | "D";
  signals: SignalScore[];
  recommendations: string[];
  summary: string;
}

function clamp(n: number) {
  return Math.max(0, Math.min(100, Math.round(n)));
}

function grade(score: number): "A" | "B" | "C" | "D" {
  if (score >= 80) return "A";
  if (score >= 65) return "B";
  if (score >= 45) return "C";
  return "D";
}

/** تشخیص ساده قلاب و CTA از متن */
export function analyzeCaption(caption: string) {
  const lines = caption.trim().split(/\n/).filter(Boolean);
  const first = (lines[0] || "").slice(0, 80);
  const hasQuestion =
    /[?؟]/.test(caption) ||
    /(کدام|چی|چطور|نظر شما|بنویسید|بگو)/.test(caption);
  const hasHook =
    first.length > 8 &&
    (/(نکته|راز|اشتباه|قبل از|اگر|۳ |5 |چطور|چرا)/.test(first) ||
      /[!💡🔥📌]/.test(first));
  const hasSaveable =
    /(نکته|آموزش|چک.?لیست|مراحل|راهنما|خلاصه|لیست)/.test(caption) ||
    (caption.match(/\n/g) || []).length >= 3;
  return { hasQuestion, hasHook, hasSaveable, lineCount: lines.length };
}

export function scoreForReels(input: AlgorithmInput): AlgorithmReport {
  const cap = analyzeCaption(input.caption);
  const duration = input.estimatedDurationSec ?? 20;

  const signals: SignalScore[] = [
    {
      name: "watch_time",
      nameFa: "زمان تماشا / تکمیل",
      weight: 0.35,
      score: clamp(
        (input.hasHookInFirstLines || cap.hasHook ? 35 : 10) +
          (duration <= 30 ? 30 : duration <= 45 ? 15 : 0) +
          (cap.lineCount <= 6 ? 15 : 5) +
          (input.hasVideo ? 20 : 0)
      ),
      tip: "قلاب در ۳ ثانیه اول + ریلز کوتاه‌تر (حدود ۱۵–۳۰ ثانیه) معمولاً تکمیل بهتری دارد.",
    },
    {
      name: "sends",
      nameFa: "ارسال در دایرکت (Send)",
      weight: 0.3,
      score: clamp(
        (cap.hasSaveable ? 25 : 5) +
          (cap.hasQuestion ? 20 : 0) +
          (/(دوست|بفرست|اشتراک|برای .* بفرست)/.test(input.caption) ? 25 : 10) +
          20
      ),
      tip: "محتوایی بسازید که ارزش «فرستادن برای یک دوست» داشته باشد؛ این قوی‌ترین سیگنال رشد برای غیرفالوور است.",
    },
    {
      name: "likes_per_reach",
      nameFa: "لایک نسبت به بازدید",
      weight: 0.2,
      score: clamp((cap.hasHook ? 30 : 15) + (input.hasVideo ? 25 : 10) + 25),
      tip: "لایک برای فالوورهای فعلی مهم‌تر است؛ شروع قوی و موضوع شفاف کمک می‌کند.",
    },
    {
      name: "saves",
      nameFa: "ذخیره",
      weight: 0.15,
      score: clamp((cap.hasSaveable || input.hasSaveableValue ? 70 : 25) + (input.hasCarousel ? 15 : 0)),
      tip: "نکات شماره‌دار، آموزش و چک‌لیست بیشتر ذخیره می‌شوند.",
    },
  ];

  const total = clamp(
    signals.reduce((s, x) => s + x.score * x.weight, 0) / signals.reduce((s, x) => s + x.weight, 0) * 100
      ? signals.reduce((s, x) => s + x.score * x.weight, 0)
      : 0
  );
  // weighted average already 0-100 scale roughly
  const totalScore = clamp(signals.reduce((s, x) => s + x.score * x.weight, 0));

  const recommendations: string[] = [];
  if (!(input.hasHookInFirstLines || cap.hasHook))
    recommendations.push("خط اول کپشن یا ۳ ثانیه اول ویدیو را قلاب‌دار کنید.");
  if (duration > 35)
    recommendations.push("برای ریلز، مدت نزدیک‌تر به ۱۵–۳۰ ثانیه را امتحان کنید.");
  if (!cap.hasSaveable && !input.hasSaveableValue)
    recommendations.push("یک ارزش قابل‌ذخیره (نکته، لیست، آموزش کوتاه) اضافه کنید.");
  if (!cap.hasQuestion)
    recommendations.push("یک سؤال در انتها بگذارید تا کامنت و گفت‌وگو بیشتر شود.");
  recommendations.push("پاسخ سریع به کامنت‌های ساعت اول را از صفحه کامنت‌ها فعال نگه دارید.");

  return {
    surface: "reels",
    totalScore,
    grade: grade(totalScore),
    signals,
    recommendations,
    summary:
      totalScore >= 70
        ? "هم‌راستا با سیگنال‌های اصلی ریلز (زمان تماشا + ارسال + لایک)."
        : "برای رشد از طریق ریلز، قلاب، کوتاهی ویدیو و قابلیت ارسال را تقویت کنید.",
  };
}

export function scoreForFeed(input: AlgorithmInput): AlgorithmReport {
  const cap = analyzeCaption(input.caption);

  const signals: SignalScore[] = [
    {
      name: "relationship",
      nameFa: "رابطه با فالوور (تعامل قبلی)",
      weight: 0.3,
      score: 55, // وابسته به رفتار واقعی اکانت؛ پایه متوسط
      tip: "پاسخ به کامنت و استوری تعاملی رابطه را قوی می‌کند و پست را در فید بالاتر می‌آورد.",
    },
    {
      name: "predicted_engagement",
      nameFa: "احتمال تعامل (کامنت/ذخیره/زمان)",
      weight: 0.35,
      score: clamp(
        (cap.hasQuestion ? 30 : 10) +
          (cap.hasSaveable || input.hasSaveableValue ? 30 : 10) +
          (input.hasCarousel ? 20 : 10) +
          (cap.hasHook ? 15 : 5)
      ),
      tip: "کاروسل آموزشی و سؤال در کپشن احتمال ذخیره و کامنت را بالا می‌برد.",
    },
    {
      name: "recency",
      nameFa: "تازگی و ثبات انتشار",
      weight: 0.2,
      score: 70,
      tip: "با زمان‌بندی منظم در SocialGrow، تازگی و ثبات را حفظ کنید.",
    },
    {
      name: "likes",
      nameFa: "لایک (برای مخاطب متصل)",
      weight: 0.15,
      score: clamp((cap.hasHook ? 40 : 20) + 30),
      tip: "برای فید، لایک نسبت به بازدید مهم است؛ موضوع شفاف برای فالوورهای فعلی.",
    },
  ];

  const totalScore = clamp(signals.reduce((s, x) => s + x.score * x.weight, 0));

  return {
    surface: "feed",
    totalScore,
    grade: grade(totalScore),
    signals,
    recommendations: [
      "در ۳۰–۶۰ دقیقه اول به کامنت‌ها پاسخ دهید.",
      "کاروسل یا محتوای قابل‌ذخیره برای فید مناسب‌تر است.",
      ...(cap.hasQuestion ? [] : ["یک CTA سؤالی به کپشن اضافه کنید."]),
    ],
    summary: "فید بیشتر به رابطه و تعامل فالوورهای فعلی وابسته است تا وایرال شدن.",
  };
}

export function scoreContent(
  input: AlgorithmInput,
  surface: IgSurface = "reels"
): AlgorithmReport {
  if (surface === "feed") return scoreForFeed(input);
  // stories/explore → از منطق نزدیک به feed/reels استفاده می‌کنیم
  if (surface === "stories") {
    const base = scoreForFeed(input);
    return {
      ...base,
      surface: "stories",
      summary: "استوری برای نزدیک ماندن به فالوور است؛ استیکر تعاملی و ریپلای مهم‌اند.",
      recommendations: [
        "استیکر سؤال/نظرسنجی بگذارید.",
        "هر روز حداقل یک استوری ثابت منتشر کنید.",
        ...base.recommendations.slice(0, 1),
      ],
    };
  }
  if (surface === "explore") {
    const base = scoreForReels({ ...input, hasSaveableValue: true });
    return {
      ...base,
      surface: "explore",
      summary: "اکسپلور به ذخیره، شیر و محبوبیت پست بین کاربران مشابه وابسته است.",
    };
  }
  return scoreForReels(input);
}

export const ALGORITHM_GUIDE = {
  topSignals: [
    { id: "watch_time", title: "زمان تماشا", desc: "مهم‌ترین سیگنال ریلز؛ تکمیل ویدیو" },
    { id: "sends", title: "ارسال دایرکت", desc: "قوی‌ترین سیگنال رشد برای غیرفالوور" },
    { id: "likes_per_reach", title: "لایک/بازدید", desc: "مهم‌تر برای فید و فالوورهای فعلی" },
    { id: "saves", title: "ذخیره", desc: "نشانه ارزش ماندگار محتوا" },
  ],
  surfaces: [
    { id: "reels", title: "ریلز", goal: "کشف و رشد" },
    { id: "feed", title: "فید", goal: "دیده شدن نزد فالوورها" },
    { id: "stories", title: "استوری", goal: "نزدیکی رابطه" },
    { id: "explore", title: "اکسپلور", goal: "کشف موضوعی" },
  ],
  notSupported: [
    "دایرکت خودکار پست به همه فالوورها (اسپم و خلاف قوانین)",
    "فالو/آنفالو و لایک انبوه رباتی",
  ],
};
EOF