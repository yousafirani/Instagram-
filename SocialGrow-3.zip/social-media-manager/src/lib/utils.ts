import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(num: number): string {
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + "M";
  if (num >= 1_000) return (num / 1_000).toFixed(1) + "K";
  return num.toString();
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function platformColor(platform: string): string {
  switch (platform) {
    case "instagram":
      return "bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400";
    case "twitter":
      return "bg-black";
    case "linkedin":
      return "bg-blue-600";
    case "tiktok":
      return "bg-black";
    case "youtube":
      return "bg-red-600";
    case "telegram":
      return "bg-sky-500";
    case "eitaa":
      return "bg-orange-500";
    case "bale":
      return "bg-green-600";
    default:
      return "bg-gray-500";
  }
}

export function platformLabel(platform: string): string {
  switch (platform) {
    case "instagram":
      return "اینستاگرام";
    case "twitter":
      return "X (توییتر)";
    case "linkedin":
      return "لینکدین";
    case "tiktok":
      return "تیک‌تاک";
    case "youtube":
      return "یوتیوب";
    case "telegram":
      return "تلگرام";
    case "eitaa":
      return "ایتا";
    case "bale":
      return "بله";
    default:
      return platform;
  }
}
