/**
 * تلگرام / ایتا / بله
 *
 * پشتیبانی‌شده (قانونی):
 * - انتشار در کانال یا گروه از طریق Bot API (وقتی ربات ادمین کانال است)
 * - پاسخ به پیام‌هایی که کاربر خودش شروع کرده (تلگرام)
 *
 * پشتیبانی‌نشده:
 * - ارسال خودکار پست به پیوی همه فالوورها / اعضای کانال (اسپم)
 */

export type MessengerPlatform = "telegram" | "eitaa" | "bale";

export interface MessengerConfig {
  platform: MessengerPlatform;
  botToken?: string;
  channelId?: string; // @channel یا chat_id
}

/** ارسال پیام به کانال تلگرام با Bot API */
export async function publishToTelegramChannel(
  botToken: string,
  chatId: string,
  text: string,
  options?: { parseMode?: "HTML" | "Markdown" }
) {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: options?.parseMode || "HTML",
      disable_web_page_preview: false,
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Telegram error: ${err}`);
  }
  return res.json();
}

/**
 * ایتا و بله: در صورت داشتن API رسمی مشابه، همان الگوی کانال اعمال می‌شود.
 * بدون توکن واقعی فقط ساختار آماده است.
 */
export async function publishToMessengerChannel(
  platform: MessengerPlatform,
  config: { botToken: string; channelId: string },
  text: string
) {
  if (platform === "telegram") {
    return publishToTelegramChannel(config.botToken, config.channelId, text);
  }

  // ایتا / بله: endpoint رسمی بسته به مستندات هر سرویس متفاوت است
  // اینجا فقط اسکلت برای اتصال بعدی
  throw new Error(
    `انتشار کانال ${platform}: توکن و مستندات API را در تنظیمات وارد کنید. پیام انبوه به پیوی کاربران پشتیبانی نمی‌شود.`
  );
}

export const MESSENGER_INFO = {
  telegram: {
    label: "تلگرام",
    allowed: "پست در کانال/گروه با ربات ادمین",
    forbidden: "فوروارد/پیام خودکار به پیوی همه اعضا بدون درخواست",
    setup: "BotFather → توکن → ربات را ادمین کانال کنید → chat_id کانال",
  },
  eitaa: {
    label: "ایتا",
    allowed: "انتشار در کانال/صفحه رسمی در صورت API",
    forbidden: "پیام انبوه خصوصی بدون رضایت",
    setup: "از پنل توسعه‌دهندگان ایتا توکن بگیرید (در صورت وجود)",
  },
  bale: {
    label: "بله",
    allowed: "انتشار در کانال/ربات طبق قوانین بله",
    forbidden: "اسپم پیوی",
    setup: "مستندات API بله / ربات رسمی",
  },
};
EOF