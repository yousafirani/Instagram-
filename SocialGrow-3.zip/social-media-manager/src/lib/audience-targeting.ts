/**
 * سیستم پیشنهاد مخاطب هدف برای محتوا
 * هدف: کمک به تولید محتوای بهتر و زمان‌بندی مناسب
 * نه برای فالو اجباری یا اسپم
 */

export type InterestCategory =
  | "business"
  | "tech"
  | "lifestyle"
  | "fashion"
  | "food"
  | "fitness"
  | "education"
  | "entertainment"
  | "travel"
  | "finance";

export interface TargetingCriteria {
  interests: InterestCategory[];
  ageRange?: [number, number];
  locations?: string[];
  languages?: string[];
  engagementLevel?: "low" | "medium" | "high";
  contentType?: "image" | "video" | "carousel" | "text";
}

export interface ContentSuggestion {
  title: string;
  description: string;
  hashtags: string[];
  bestTime: string;
  platform: string;
  reason: string;
}

export interface AudienceInsight {
  segmentName: string;
  sizeEstimate: string;
  topInterests: string[];
  recommendedContent: string[];
  bestPostingTimes: string[];
  suggestedHashtags: string[];
}

const INTEREST_LABELS: Record<InterestCategory, string> = {
  business: "کسب‌وکار",
  tech: "تکنولوژی",
  lifestyle: "سبک زندگی",
  fashion: "مد و فشن",
  food: "غذا و آشپزی",
  fitness: "ورزش و تناسب اندام",
  education: "آموزش",
  entertainment: "سرگرمی",
  travel: "سفر",
  finance: "مالی و سرمایه‌گذاری",
};

const HASHTAG_BANK: Record<InterestCategory, string[]> = {
  business: ["#کسب_و_کار", "#کارآفرینی", "#استارتاپ", "#مدیریت", "#رشد_کسب_و_کار"],
  tech: ["#تکنولوژی", "#هوش_مصنوعی", "#برنامه_نویسی", "#نوآوری", "#دیجیتال"],
  lifestyle: ["#سبک_زندگی", "#انگیزشی", "#موفقیت", "#روزمرگی"],
  fashion: ["#مد", "#فشن", "#استایل", "#لباس"],
  food: ["#غذا", "#آشپزی", "#رسپی", "#خوراکی"],
  fitness: ["#ورزش", "#تناسب_اندام", "#سلامتی", "#باشگاه"],
  education: ["#آموزش", "#یادگیری", "#کتاب", "#مهارت"],
  entertainment: ["#سرگرمی", "#فیلم", "#موسیقی", "#طنز"],
  travel: ["#سفر", "#گردشگری", "#طبیعت", "#ماجراجویی"],
  finance: ["#سرمایه_گذاری", "#مالی", "#بورس", "#اقتصاد"],
};

const BEST_TIMES: Record<string, string[]> = {
  instagram: ["۱۹:۰۰–۲۱:۰۰", "۱۲:۰۰–۱۴:۰۰"],
  twitter: ["۱۲:۰۰–۱۴:۰۰", "۲۰:۰۰–۲۲:۰۰"],
  linkedin: ["۰۸:۰۰–۱۰:۰۰", "۱۷:۰۰–۱۸:۰۰"],
  tiktok: ["۱۹:۰۰–۲۳:۰۰", "۱۲:۰۰–۱۴:۰۰"],
};

export function getInterestLabel(cat: InterestCategory): string {
  return INTEREST_LABELS[cat] || cat;
}

export function generateAudienceInsights(criteria: TargetingCriteria): AudienceInsight[] {
  const insights: AudienceInsight[] = [];

  for (const interest of criteria.interests) {
    const hashtags = HASHTAG_BANK[interest] || [];
    insights.push({
      segmentName: `علاقه‌مندان به ${INTEREST_LABELS[interest]}`,
      sizeEstimate: `${Math.floor(Math.random() * 40 + 10)}٪ از فالوورهای شما`,
      topInterests: [INTEREST_LABELS[interest], "محتوای آموزشی", "نکات کاربردی"],
      recommendedContent: [
        `پست آموزشی کوتاه درباره ${INTEREST_LABELS[interest]}`,
        "استوری پشت‌صحنه",
        "کاروسل نکات ۵‌تایی",
        "ویدیو کوتاه (Reels/TikTok)",
      ],
      bestPostingTimes: BEST_TIMES.instagram,
      suggestedHashtags: hashtags,
    });
  }

  if (criteria.locations && criteria.locations.length > 0) {
    insights.push({
      segmentName: `مخاطبان ${criteria.locations.join("، ")}`,
      sizeEstimate: "بر اساس لوکیشن اعلام‌شده",
      topInterests: criteria.interests.map(getInterestLabel),
      recommendedContent: [
        "محتوای محلی و مرتبط با شهر/کشور",
        "اشاره به رویدادهای محلی",
      ],
      bestPostingTimes: ["۲۰:۰۰–۲۲:۰۰"],
      suggestedHashtags: criteria.locations.map((l) => `#${l}`),
    });
  }

  return insights;
}

export function generateContentSuggestions(
  criteria: TargetingCriteria,
  platform: string = "instagram"
): ContentSuggestion[] {
  const suggestions: ContentSuggestion[] = [];
  const times = BEST_TIMES[platform] || BEST_TIMES.instagram;

  for (const interest of criteria.interests.slice(0, 4)) {
    const hashtags = HASHTAG_BANK[interest] || [];
    suggestions.push({
      title: `محتوای آموزشی ${INTEREST_LABELS[interest]}`,
      description: `یک کاروسل یا ویدیو کوتاه با ۳–۵ نکته کاربردی در حوزه ${INTEREST_LABELS[interest]} که فالوورهای هدف شما را درگیر کند.`,
      hashtags: hashtags.slice(0, 5),
      bestTime: times[0],
      platform,
      reason: `بر اساس علاقه انتخاب‌شده: ${INTEREST_LABELS[interest]}`,
    });
  }

  suggestions.push({
    title: "پشت‌صحنه و داستان برند",
    description: "محتوای انسانی و واقعی که اعتماد می‌سازد و نرخ تعامل را بالا می‌برد.",
    hashtags: ["#پشت_صحنه", "#داستان_برند", "#واقعی"],
    bestTime: times[1] || times[0],
    platform,
    reason: "محتوای اعتمادساز برای همه سگمنت‌ها",
  });

  return suggestions;
}

export const ALL_INTERESTS: InterestCategory[] = [
  "business",
  "tech",
  "lifestyle",
  "fashion",
  "food",
  "fitness",
  "education",
  "entertainment",
  "travel",
  "finance",
];
