/**
 * Instagram Graph API — اتصال و انتشار
 *
 * پیش‌نیاز Meta:
 * 1. پیج اینستاگرام Business یا Creator
 * 2. اتصال به Facebook Page
 * 3. App در developers.facebook.com با Instagram Graph API
 * 4. توکن با دسترسی‌های:
 *    instagram_basic, instagram_content_publish,
 *    pages_show_list, pages_read_engagement, business_management
 *
 * مستندات: https://developers.facebook.com/docs/instagram-platform
 */

const GRAPH_API = process.env.INSTAGRAM_GRAPH_URL || "https://graph.facebook.com/v21.0";

export interface InstagramAccountInfo {
  id: string;
  username: string;
  name?: string;
  profile_picture_url?: string;
  followers_count?: number;
  media_count?: number;
  biography?: string;
  website?: string;
}

export interface PublishResult {
  id: string;
  containerId?: string;
}

function authQuery(accessToken: string) {
  return `access_token=${encodeURIComponent(accessToken)}`;
}

/** اطلاعات اکانت اینستاگرام */
export async function getInstagramAccount(
  accessToken: string,
  igUserId: string
): Promise<InstagramAccountInfo> {
  const fields =
    "id,username,name,profile_picture_url,followers_count,media_count,biography,website";
  const url = `${GRAPH_API}/${igUserId}?fields=${fields}&${authQuery(accessToken)}`;
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Instagram getAccount: ${res.status} ${await res.text()}`);
  }
  return res.json();
}

/**
 * از توکن صفحه فیسبوک، آی‌دی اینستاگرام بیزنس را پیدا می‌کند
 */
export async function findInstagramBusinessAccount(
  accessToken: string,
  pageId: string
): Promise<string | null> {
  const url = `${GRAPH_API}/${pageId}?fields=instagram_business_account&${authQuery(accessToken)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  const data = await res.json();
  return data.instagram_business_account?.id || null;
}

/** لیست صفحات فیسبوک کاربر (برای انتخاب پیج متصل به IG) */
export async function listFacebookPages(accessToken: string) {
  const url = `${GRAPH_API}/me/accounts?fields=id,name,access_token,instagram_business_account&${authQuery(accessToken)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  const data = await res.json();
  return data.data || [];
}

/** انتشار عکس (دو مرحله: container → publish) */
export async function publishInstagramPhoto(
  accessToken: string,
  igUserId: string,
  imageUrl: string,
  caption: string
): Promise<PublishResult> {
  const containerUrl =
    `${GRAPH_API}/${igUserId}/media?` +
    `image_url=${encodeURIComponent(imageUrl)}` +
    `&caption=${encodeURIComponent(caption)}` +
    `&${authQuery(accessToken)}`;

  const containerRes = await fetch(containerUrl, { method: "POST" });
  if (!containerRes.ok) {
    throw new Error(`IG container: ${await containerRes.text()}`);
  }
  const { id: creationId } = await containerRes.json();

  // کمی صبر برای پردازش مدیا (در پروداکشن status را چک کنید)
  await waitForContainer(accessToken, creationId);

  const publishRes = await fetch(
    `${GRAPH_API}/${igUserId}/media_publish?creation_id=${creationId}&${authQuery(accessToken)}`,
    { method: "POST" }
  );
  if (!publishRes.ok) {
    throw new Error(`IG publish: ${await publishRes.text()}`);
  }
  const published = await publishRes.json();
  return { id: published.id, containerId: creationId };
}

/** انتشار ریلز / ویدیو */
export async function publishInstagramReel(
  accessToken: string,
  igUserId: string,
  videoUrl: string,
  caption: string
): Promise<PublishResult> {
  const containerUrl =
    `${GRAPH_API}/${igUserId}/media?` +
    `media_type=REELS` +
    `&video_url=${encodeURIComponent(videoUrl)}` +
    `&caption=${encodeURIComponent(caption)}` +
    `&${authQuery(accessToken)}`;

  const containerRes = await fetch(containerUrl, { method: "POST" });
  if (!containerRes.ok) {
    throw new Error(`IG reel container: ${await containerRes.text()}`);
  }
  const { id: creationId } = await containerRes.json();
  await waitForContainer(accessToken, creationId, 12);

  const publishRes = await fetch(
    `${GRAPH_API}/${igUserId}/media_publish?creation_id=${creationId}&${authQuery(accessToken)}`,
    { method: "POST" }
  );
  if (!publishRes.ok) {
    throw new Error(`IG reel publish: ${await publishRes.text()}`);
  }
  const published = await publishRes.json();
  return { id: published.id, containerId: creationId };
}

async function waitForContainer(
  accessToken: string,
  creationId: string,
  maxAttempts = 8
) {
  for (let i = 0; i < maxAttempts; i++) {
    const res = await fetch(
      `${GRAPH_API}/${creationId}?fields=status_code&${authQuery(accessToken)}`
    );
    if (res.ok) {
      const data = await res.json();
      if (data.status_code === "FINISHED") return;
      if (data.status_code === "ERROR") {
        throw new Error("Instagram media processing failed");
      }
    }
    await new Promise((r) => setTimeout(r, 2000));
  }
}

/** کامنت‌های یک رسانه */
export async function getInstagramComments(
  accessToken: string,
  mediaId: string
) {
  const url = `${GRAPH_API}/${mediaId}/comments?fields=id,text,username,timestamp,replies&${authQuery(accessToken)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  const data = await res.json();
  return data.data || [];
}

/** پاسخ به کامنت */
export async function replyToInstagramComment(
  accessToken: string,
  commentId: string,
  message: string
) {
  const url =
    `${GRAPH_API}/${commentId}/replies?` +
    `message=${encodeURIComponent(message)}&${authQuery(accessToken)}`;
  const res = await fetch(url, { method: "POST" });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

/** آخرین رسانه‌ها */
export async function getRecentMedia(
  accessToken: string,
  igUserId: string,
  limit = 10
) {
  const fields = "id,caption,media_type,media_url,thumbnail_url,timestamp,like_count,comments_count";
  const url = `${GRAPH_API}/${igUserId}/media?fields=${fields}&limit=${limit}&${authQuery(accessToken)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  const data = await res.json();
  return data.data || [];
}

/** تست اعتبار توکن */
export async function validateInstagramToken(
  accessToken: string,
  igUserId: string
): Promise<{ ok: boolean; account?: InstagramAccountInfo; error?: string }> {
  try {
    const account = await getInstagramAccount(accessToken, igUserId);
    return { ok: true, account };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
}

export const INSTAGRAM_SETUP_STEPS = [
  "در Meta for Developers یک App بسازید (نوع Business)",
  "محصول Instagram را اضافه کنید و Instagram API with Instagram Login یا Graph API را فعال کنید",
  "اکانت اینستاگرام را Business/Creator کنید و به Facebook Page وصل کنید",
  "با Graph API Explorer یا Login، User/Page Token با دسترسی‌های لازم بگیرید",
  "Long-lived token بسازید (حدود ۶۰ روز) و در SocialGrow ذخیره کنید",
  "IG User ID (آی‌دی عددی بیزنس) و Access Token را در اتصال اینستاگرام وارد کنید",
];

/**
 * ارسال پیام دایرکت اینستاگرام (Messaging API)
 * فقط در پاسخ به پیام کاربر یا در پنجره ۲۴ ساعته مجاز است.
 */
export async function sendInstagramDM(
  pageAccessToken: string,
  recipientIgsid: string,
  text: string
) {
  const url = `${GRAPH_API}/me/messages`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      recipient: { id: recipientIgsid },
      message: { text },
      access_token: pageAccessToken,
    }),
  });
  if (!res.ok) {
    throw new Error(`IG DM send failed: ${await res.text()}`);
  }
  return res.json();
}
