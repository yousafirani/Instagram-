import NextAuth from "next-auth";
import Twitter from "next-auth/providers/twitter";
import type { NextAuthConfig } from "next-auth";

/**
 * تنظیمات احراز هویت
 * برای اتصال واقعی به X (توییتر) باید این متغیرهای محیطی را پر کنید:
 * AUTH_TWITTER_ID     = Client ID از developer.x.com
 * AUTH_TWITTER_SECRET = Client Secret
 * AUTH_SECRET         = یک رشته تصادفی قوی (openssl rand -base64 32)
 */
export const authConfig: NextAuthConfig = {
  providers: [
    Twitter({
      clientId: process.env.AUTH_TWITTER_ID,
      clientSecret: process.env.AUTH_TWITTER_SECRET,
      // برای دسترسی به پست گذاشتن نیاز به OAuth 2.0 با PKCE و scopeهای مناسب است
      // در نسخه فعلی Twitter provider از OAuth 1.0a استفاده می‌کند
      // برای OAuth 2.0 کامل‌تر باید custom provider بنویسید
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      if (account) {
        token.accessToken = account.access_token;
        token.refreshToken = account.refresh_token;
        token.provider = account.provider;
        token.providerAccountId = account.providerAccountId;
      }
      if (profile) {
        // @ts-expect-error Twitter profile shape
        token.username = profile.data?.username || profile.screen_name;
      }
      return token;
    },
    async session({ session, token }) {
      // @ts-expect-error custom fields
      session.accessToken = token.accessToken;
      // @ts-expect-error
      session.username = token.username;
      // @ts-expect-error
      session.provider = token.provider;
      return session;
    },
  },
  pages: {
    signIn: "/accounts",
  },
  secret: process.env.AUTH_SECRET,
};

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig);
