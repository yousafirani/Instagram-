/**
 * تشخیص فالوور مشکوک / فیک – فقط تحلیلی
 * هیچ اکشن خودکاری (حذف/بلاک) انجام نمی‌دهد.
 * شما گزارش را می‌بینید و خودتان تصمیم می‌گیرید.
 */

export interface FollowerProfile {
  id: string;
  username: string;
  displayName?: string;
  avatarUrl?: string;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  hasProfilePic: boolean;
  isPrivate: boolean;
  bio?: string;
  engagementRate?: number; // درصد
  lastActiveDays?: number; // روز از آخرین فعالیت
  accountAgeDays?: number;
}

export interface SuspicionScore {
  score: number; // 0–100 (بالاتر = مشکوک‌تر)
  reasons: string[];
  level: "low" | "medium" | "high" | "critical";
}

export interface FollowerAnalysisResult {
  profile: FollowerProfile;
  suspicion: SuspicionScore;
}

/**
 * الگوریتم تشخیص مشکوک بودن
 * بر اساس معیارهای عمومی و شناخته‌شده
 */
export function analyzeFollower(profile: FollowerProfile): SuspicionScore {
  let score = 0;
  const reasons: string[] = [];

  // ۱. نسبت فالوینگ به فالوور (فالوور خیلی کم، فالوینگ خیلی زیاد)
  if (profile.followingCount > 0) {
    const ratio = profile.followersCount / profile.followingCount;
    if (ratio < 0.1 && profile.followingCount > 500) {
      score += 25;
      reasons.push("نسبت فالوور به فالوینگ بسیار پایین (احتمال فیک یا اسپم)");
    } else if (ratio < 0.3 && profile.followingCount > 1000) {
      score += 15;
      reasons.push("نسبت فالوور/فالوینگ مشکوک");
    }
  }

  // ۲. بدون عکس پروفایل
  if (!profile.hasProfilePic) {
    score += 20;
    reasons.push("بدون عکس پروفایل");
  }

  // ۳. تعداد پست خیلی کم با فالوور بالا یا برعکس
  if (profile.postsCount === 0 && profile.followersCount > 50) {
    score += 15;
    reasons.push("بدون هیچ پستی");
  }
  if (profile.postsCount < 3 && profile.followersCount > 5000) {
    score += 10;
    reasons.push("پست بسیار کم نسبت به تعداد فالوور");
  }

  // ۴. نرخ تعامل بسیار پایین
  if (profile.engagementRate !== undefined && profile.engagementRate < 0.5) {
    score += 15;
    reasons.push(`نرخ تعامل بسیار پایین (${profile.engagementRate}%)`);
  }

  // ۵. اکانت خیلی جدید با فالوور بالا
  if (profile.accountAgeDays !== undefined && profile.accountAgeDays < 30 && profile.followersCount > 1000) {
    score += 20;
    reasons.push("اکانت خیلی جدید با فالوور غیرعادی");
  }

  // ۶. غیرفعال بودن طولانی
  if (profile.lastActiveDays !== undefined && profile.lastActiveDays > 180) {
    score += 10;
    reasons.push("بیش از ۶ ماه غیرفعال");
  }

  // ۷. بایو خالی + بدون عکس
  if ((!profile.bio || profile.bio.trim().length < 3) && !profile.hasProfilePic) {
    score += 10;
    reasons.push("بایو خالی و بدون عکس");
  }

  score = Math.min(100, score);

  let level: SuspicionScore["level"] = "low";
  if (score >= 70) level = "critical";
  else if (score >= 50) level = "high";
  else if (score >= 30) level = "medium";

  return { score, reasons, level };
}

/**
 * تولید داده نمونه برای دمو (در پروداکشن از API پلتفرم می‌آید)
 */
export function generateMockFollowers(count = 40): FollowerProfile[] {
  const usernames = [
    "user_ali", "sara_shop", "reza_photo", "bot_farm_99", "fake_like_pro",
    "real_customer", "maryam_art", "spam_account_x", "legit_buyer", "empty_profile",
    "high_follow_low_eng", "new_account_2026", "inactive_user", "business_pro",
    "random_numbers_12345", "no_pic_user", "engagement_king", "ghost_follower",
  ];

  return Array.from({ length: count }, (_, i) => {
    const isSuspicious = Math.random() > 0.55;
    const following = isSuspicious
      ? Math.floor(Math.random() * 4000) + 800
      : Math.floor(Math.random() * 800) + 50;
    const followers = isSuspicious
      ? Math.floor(Math.random() * 200) + 5
      : Math.floor(Math.random() * 5000) + 100;

    return {
      id: `f_${i}`,
      username: usernames[i % usernames.length] + (i > usernames.length ? `_${i}` : ""),
      displayName: `کاربر ${i + 1}`,
      avatarUrl: isSuspicious && Math.random() > 0.4
        ? undefined
        : `https://api.dicebear.com/7.x/avataaars/svg?seed=f${i}`,
      followersCount: followers,
      followingCount: following,
      postsCount: isSuspicious ? Math.floor(Math.random() * 3) : Math.floor(Math.random() * 80) + 5,
      hasProfilePic: !(isSuspicious && Math.random() > 0.5),
      isPrivate: Math.random() > 0.7,
      bio: isSuspicious && Math.random() > 0.6 ? "" : "علاقه‌مند به محتوا و کسب‌وکار",
      engagementRate: isSuspicious
        ? Math.random() * 0.8
        : Math.random() * 4 + 1.5,
      lastActiveDays: isSuspicious && Math.random() > 0.5
        ? Math.floor(Math.random() * 200) + 100
        : Math.floor(Math.random() * 30),
      accountAgeDays: isSuspicious && Math.random() > 0.6
        ? Math.floor(Math.random() * 25) + 1
        : Math.floor(Math.random() * 800) + 60,
    };
  });
}

export function analyzeAll(followers: FollowerProfile[]): FollowerAnalysisResult[] {
  return followers
    .map((profile) => ({
      profile,
      suspicion: analyzeFollower(profile),
    }))
    .sort((a, b) => b.suspicion.score - a.suspicion.score);
}
