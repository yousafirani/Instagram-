/**
 * پیشنهاد پاسخ هوشمند به کامنت‌ها
 * از OpenAI SDK استفاده می‌کند (با xAI Grok یا OpenAI)
 *
 * متغیرهای محیطی مورد نیاز:
 *   OPENAI_API_KEY  یا  XAI_API_KEY
 *   OPENAI_BASE_URL (اختیاری – برای xAI: https://api.x.ai/v1)
 */

import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.XAI_API_KEY || process.env.OPENAI_API_KEY || "sk-demo",
  baseURL: process.env.OPENAI_BASE_URL || "https://api.x.ai/v1", // پیش‌فرض xAI Grok
});

export interface SuggestReplyOptions {
  comment: string;
  postContent?: string;
  platform: string;
  brandTone?: "friendly" | "professional" | "casual" | "humorous";
  language?: "fa" | "en";
}

export async function suggestCommentReply(options: SuggestReplyOptions): Promise<string> {
  const {
    comment,
    postContent = "",
    platform,
    brandTone = "friendly",
    language = "fa",
  } = options;

  // اگر کلید API وجود نداشته باشد، پاسخ شبیه‌سازی شده برمی‌گردانیم
  if (!process.env.XAI_API_KEY && !process.env.OPENAI_API_KEY) {
    return generateMockReply(comment, language);
  }

  const systemPrompt =
    language === "fa"
      ? `تو دستیار پاسخ‌دهی به کامنت‌های شبکه‌های اجتماعی هستی. 
لحن برند: ${brandTone === "friendly" ? "دوستانه و گرم" : brandTone === "professional" ? "حرفه‌ای" : brandTone === "casual" ? "غیررسمی" : "شوخ‌طبع"}.
پاسخ‌ها کوتاه (حداکثر ۲ جمله)، طبیعی و به زبان فارسی باشند.
هرگز لینک یا تبلیغ مستقیم نگذار مگر اینکه لازم باشد.`
      : `You are a social media comment reply assistant. Tone: ${brandTone}. Keep replies short (max 2 sentences).`;

  const userPrompt =
    language === "fa"
      ? `پلتفرم: ${platform}
محتوای پست: ${postContent || "نامشخص"}
کامنت کاربر: "${comment}"

یک پاسخ مناسب پیشنهاد بده:`
      : `Platform: ${platform}\nPost: ${postContent}\nComment: "${comment}"\nSuggest a reply:`;

  try {
    const completion = await client.chat.completions.create({
      model: process.env.AI_MODEL || "grok-3", // یا gpt-4o-mini
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      max_tokens: 150,
      temperature: 0.7,
    });

    return completion.choices[0]?.message?.content?.trim() || generateMockReply(comment, language);
  } catch (error) {
    console.error("AI suggestion error:", error);
    return generateMockReply(comment, language);
  }
}

function generateMockReply(comment: string, language: string): string {
  if (language === "fa") {
    const replies = [
      "ممنون از نظرتون! خوشحالیم که براتون مفید بوده 💙",
      "خیلی ممنون از همراهیتون. سوالی داشتید خوشحال می‌شیم کمک کنیم!",
      "نظر قشنگتون انرژی ما رو دوچندان کرد ✨",
      "مرسی که وقت گذاشتید و کامنت گذاشتید. به زودی بیشتر در این مورد می‌گیم!",
    ];
    return replies[Math.floor(Math.random() * replies.length)];
  }
  return "Thanks for your comment! We appreciate your feedback 💙";
}
