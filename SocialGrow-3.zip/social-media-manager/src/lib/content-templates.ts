/**
 * قالب‌های نوع پست مفید + پک هشتگ
 * برای پر کردن سریع کپشن و هشتگ در زمان‌بندی
 */

export type PostType =
  | "educational"
  | "behind_scenes"
  | "promo"
  | "engagement"
  | "storytelling"
  | "tips"
  | "testimonial"
  | "announcement";

export interface ContentTemplate {
  id: PostType;
  title: string;
  description: string;
  platforms: string[];
  captionTemplate: string;
  hashtags: string[];
  bestTimes: string[];
  mediaHint: string;
}

export const CONTENT_TEMPLATES: ContentTemplate[] = [
  {
    id: "educational",
    title: "آموزشی / کاروسل نکات",
    description: "۳ تا ۷ نکته کاربردی – بالاترین نرخ ذخیره و اشتراک",
    platforms: ["instagram", "linkedin", "twitter", "youtube"],
    captionTemplate:
      "۳ نکته مهم درباره [موضوع] که کمتر کسی می‌داند:\n\n۱) ...\n۲) ...\n۳) ...\n\nکدام نکته براتون مفیدتر بود؟ در کامنت بنویسید 👇",
    hashtags: ["#آموزش", "#نکات", "#رشد", "#یادگیری", "#محتوا"],
    bestTimes: ["۱۲:۰۰–۱۴:۰۰", "۱۹:۰۰–۲۱:۰۰"],
    mediaHint: "کاروسل تصویر یا ریلز کوتاه",
  },
  {
    id: "behind_scenes",
    title: "پشت‌صحنه / داستان برند",
    description: "اعتمادسازی و ارتباط انسانی",
    platforms: ["instagram", "tiktok", "youtube"],
    captionTemplate:
      "پشت‌صحنه امروز تیم ما 🎥\n\n[یک جمله واقعی از فرآیند کار]\n\nشما دوست دارید از کدوم بخش کار بیشتر ببینید؟",
    hashtags: ["#پشت_صحنه", "#داستان_برند", "#واقعی", "#تیم"],
    bestTimes: ["۱۸:۰۰–۲۰:۰۰"],
    mediaHint: "ویدیو یا چند عکس از محیط کار",
  },
  {
    id: "tips",
    title: "نکته سریع (Quick Tip)",
    description: "یک نکته کوتاه و قابل اجرا – مناسب استوری و پست",
    platforms: ["instagram", "twitter", "tiktok", "linkedin"],
    captionTemplate:
      "نکته امروز 💡\n\n[نکته در ۱–۲ جمله]\n\nاگر این را امتحان کردید نتیجه را در کامنت بگویید.",
    hashtags: ["#نکته", "#روزانه", "#کاربردی"],
    bestTimes: ["۰۹:۰۰–۱۱:۰۰", "۲۰:۰۰–۲۲:۰۰"],
    mediaHint: "یک تصویر ساده یا اسلاید متنی",
  },
  {
    id: "engagement",
    title: "تعاملی / سؤال از مخاطب",
    description: "افزایش کامنت و رسیدن به اکسپلور",
    platforms: ["instagram", "twitter", "linkedin"],
    captionTemplate:
      "سؤال امروز از شما:\n\n[سؤال باز]\n\nجواب‌ها را می‌خوانم و به بهترین‌ها پاسخ می‌دهم 👇",
    hashtags: ["#نظر_شما", "#گفتگو", "#انجمن"],
    bestTimes: ["۱۹:۰۰–۲۱:۰۰"],
    mediaHint: "تصویر مرتبط یا فقط متن قوی",
  },
  {
    id: "promo",
    title: "معرفی محصول / پیشنهاد",
    description: "فروش نرم بدون اسپم – بعد از محتوای ارزشی",
    platforms: ["instagram", "linkedin", "youtube", "twitter"],
    captionTemplate:
      "اگر دنبال [مزیت اصلی] هستید، این برای شماست.\n\n✅ [ویژگی ۱]\n✅ [ویژگی ۲]\n✅ [ویژگی ۳]\n\nلینک در بایو / استوری\nسؤالی بود بپرسید.",
    hashtags: ["#پیشنهاد", "#محصول", "#فرصت"],
    bestTimes: ["۱۲:۰۰–۱۴:۰۰", "۲۰:۰۰–۲۱:۰۰"],
    mediaHint: "عکس محصول یا دموی کوتاه",
  },
  {
    id: "storytelling",
    title: "داستان / تجربه شخصی",
    description: "ارتباط عاطفی و به یاد ماندنی",
    platforms: ["instagram", "linkedin", "youtube"],
    captionTemplate:
      "چند وقت پیش [شروع داستان]...\n\nبعدش [چالش]...\n\nدر نهایت [نتیجه و درس].\n\nاگر شما هم تجربه مشابهی دارید تعریف کنید.",
    hashtags: ["#داستان", "#تجربه", "#انگیزشی"],
    bestTimes: ["۲۰:۰۰–۲۲:۰۰"],
    mediaHint: "عکس شخصی یا کاور داستانی",
  },
  {
    id: "testimonial",
    title: "نظر مشتری / اثبات اجتماعی",
    description: "اعتماد برای خرید",
    platforms: ["instagram", "linkedin", "youtube"],
    captionTemplate:
      "بازخورد یکی از همراهان ما:\n\n«[نقل‌قول مشتری]»\n\n— [نام / نقش]\n\nممنون از اعتمادتون 💙\nشما هم تجربه کار با ما را داشتید؟",
    hashtags: ["#رضایت_مشتری", "#نظرات", "#اعتماد"],
    bestTimes: ["۱۱:۰۰–۱۳:۰۰"],
    mediaHint: "اسکرین‌شات نظر یا ویدیو کوتاه مشتری",
  },
  {
    id: "announcement",
    title: "اطلاعیه / خبر",
    description: "رویداد، محصول جدید، تغییر مهم",
    platforms: ["instagram", "twitter", "linkedin", "youtube", "tiktok"],
    captionTemplate:
      "خبر مهم 📢\n\n[عنوان خبر]\n\n[۲–۳ جمله توضیح]\n\nجزئیات بیشتر به زودی / لینک در بایو",
    hashtags: ["#خبر", "#اطلاعیه", "#جدید"],
    bestTimes: ["۱۰:۰۰–۱۲:۰۰", "۱۸:۰۰–۲۰:۰۰"],
    mediaHint: "بنر یا کاور خبری",
  },
];

export function getTemplate(id: PostType): ContentTemplate | undefined {
  return CONTENT_TEMPLATES.find((t) => t.id === id);
}

export function suggestHashtagsForText(text: string): string[] {
  const lower = text.toLowerCase();
  const tags = new Set<string>();

  const rules: [RegExp, string[]][] = [
    [/آموزش|نکته|یادگیر/, ["#آموزش", "#نکات", "#یادگیری"]],
    [/محصول|فروش|خرید|پیشنهاد/, ["#محصول", "#پیشنهاد"]],
    [/تیم|پشت.?صحنه|برند/, ["#پشت_صحنه", "#تیم", "#برند"]],
    [/سؤال|نظر|شما/, ["#نظر_شما", "#گفتگو"]],
    [/رشد|کسب.?و.?کار|استارتاپ/, ["#رشد_کسب_و_کار", "#کارآفرینی"]],
    [/ویدیو|یوتیوب|آموزش تصویری/, ["#ویدیو", "#یوتیوب"]],
  ];

  for (const [re, hs] of rules) {
    if (re.test(lower) || re.test(text)) hs.forEach((h) => tags.add(h));
  }

  if (tags.size === 0) {
    ["#محتوا", "#روزانه", "#الهام"].forEach((h) => tags.add(h));
  }

  return Array.from(tags).slice(0, 8);
}
