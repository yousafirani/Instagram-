/**
 * قوانین پاسخ خودکار دایرکت
 * فقط وقتی مخاطب خودش پیام می‌دهد — نه اسپم انبوه
 */

export interface DmRuleInput {
  id?: string;
  platform?: string;
  keyword: string;
  matchType?: "exact" | "contains";
  response: string;
  active?: boolean;
  priority?: number;
  hitCount?: number;
}

/** قوانین پیش‌فرض نمونه */
export const DEFAULT_DM_RULES: DmRuleInput[] = [
  {
    id: "default_price",
    keyword: "قیمت",
    matchType: "contains",
    response:
      "سلام 👋\n\nقیمت و شرایط فعلی:\n\n• پلن پایه: ۲۹۰ هزار تومان / ماه\n• پلن حرفه‌ای: ۵۹۰ هزار تومان / ماه\n• پلن سازمانی: توافقی\n\nشامل: زمان‌بندی پست، پاسخ کامنت، گزارش هفتگی\n\nبرای سفارش عدد ۱ را بفرستید یا با پشتیبانی هماهنگ کنید.",
    active: true,
    priority: 10,
  },
  {
    id: "default_conditions",
    keyword: "شرایط",
    matchType: "contains",
    response:
      "شرایط همکاری:\n\n۱) پرداخت ماهانه یا سه‌ماهه\n۲) محتوای اصلی توسط شما یا تیم ما (قابل توافق)\n۳) لغو تا ۷ روز قبل از تمدید\n۴) پشتیبانی در ساعات اداری\n\nبرای قیمت، کلمه «قیمت» را بفرستید.",
    active: true,
    priority: 5,
  },
  {
    id: "default_hello",
    keyword: "سلام",
    matchType: "exact",
    response:
      "سلام، خوش آمدید 🌟\n\nاگر قیمت می‌خواهید کلمه «قیمت» را بفرستید.\nاگر شرایط را می‌خواهید «شرایط» را بفرستید.",
    active: true,
    priority: 1,
  },
];

let memoryRules: DmRuleInput[] = DEFAULT_DM_RULES.map((r) => ({ ...r }));

export function listMemoryRules() {
  return [...memoryRules].sort((a, b) => (b.priority || 0) - (a.priority || 0));
}

export function setMemoryRules(rules: DmRuleInput[]) {
  memoryRules = rules;
}

export function upsertMemoryRule(rule: DmRuleInput) {
  const keyword = rule.keyword.trim();
  const idx = memoryRules.findIndex(
    (r) => r.keyword === keyword && (r.platform || "instagram") === (rule.platform || "instagram")
  );
  const item: DmRuleInput = {
    id: rule.id || `rule_${Date.now()}`,
    platform: rule.platform || "instagram",
    keyword,
    matchType: rule.matchType || "contains",
    response: rule.response,
    active: rule.active !== false,
    priority: rule.priority ?? 0,
    hitCount: rule.hitCount ?? 0,
  };
  if (idx >= 0) memoryRules[idx] = { ...memoryRules[idx], ...item };
  else memoryRules.push(item);
  return item;
}

export function deleteMemoryRule(id: string) {
  memoryRules = memoryRules.filter((r) => r.id !== id);
}

export function matchRule(
  text: string,
  rules: DmRuleInput[]
): DmRuleInput | null {
  const normalized = text.trim().toLowerCase();
  if (!normalized) return null;

  const active = rules
    .filter((r) => r.active !== false)
    .sort((a, b) => (b.priority || 0) - (a.priority || 0));

  for (const rule of active) {
    const kw = rule.keyword.trim().toLowerCase();
    if (!kw) continue;
    if (rule.matchType === "exact") {
      if (normalized === kw) return rule;
    } else {
      if (normalized.includes(kw)) return rule;
    }
  }
  return null;
}
