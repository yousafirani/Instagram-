import { NextRequest, NextResponse } from "next/server";
import { matchRule, listMemoryRules, setMemoryRules } from "@/lib/dm-rules";
import { sendInstagramDM } from "@/lib/instagram";

/**
 * Webhook اینستاگرام / فیسبوک برای پیام‌های دایرکت
 *
 * تنظیم در Meta App:
 * Callback URL: https://YOUR_DOMAIN/api/instagram/webhook
 * Verify Token: همان INSTAGRAM_WEBHOOK_VERIFY_TOKEN در .env
 * Subscribe: messages
 *
 * فقط به پیام ورودی کاربر پاسخ می‌دهد (کلمه کلیدی → قیمت/شرایط)
 */

const VERIFY_TOKEN =
  process.env.INSTAGRAM_WEBHOOK_VERIFY_TOKEN || "socialgrow_verify";

async function loadRules() {
  try {
    const { prisma } = await import("@/lib/prisma");
    const rows = await prisma.dmRule.findMany({ where: { active: true } });
    if (rows.length) {
      setMemoryRules(
        rows.map((r) => ({
          id: r.id,
          keyword: r.keyword,
          response: r.response,
          matchType: (r.matchType as "exact" | "contains") || "contains",
          active: r.active,
          priority: r.priority,
          platform: r.platform,
        }))
      );
    }
  } catch {
    /* defaults in memory */
  }
}

/** تأیید Webhook توسط Meta */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    return new NextResponse(challenge || "", { status: 200 });
  }
  return NextResponse.json({ error: "Forbidden" }, { status: 403 });
}

/** دریافت پیام دایرکت */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // ساختار استاندارد Meta webhook
    if (body.object !== "instagram" && body.object !== "page") {
      return NextResponse.json({ status: "ignored" });
    }

    await loadRules();
    const rules = listMemoryRules();
    const pageToken =
      process.env.INSTAGRAM_PAGE_ACCESS_TOKEN ||
      process.env.INSTAGRAM_ACCESS_TOKEN ||
      "";

    const entries = body.entry || [];
    for (const entry of entries) {
      const messaging = entry.messaging || entry.standby || [];
      for (const event of messaging) {
        const senderId = event.sender?.id;
        const text: string | undefined = event.message?.text;
        // نادیده گرفتن echo (پیام خودمان)
        if (event.message?.is_echo) continue;
        if (!senderId || !text) continue;

        const rule = matchRule(text, rules);
        if (!rule) continue;

        if (!pageToken) {
          console.warn("DM rule matched but no INSTAGRAM_PAGE_ACCESS_TOKEN");
          continue;
        }

        try {
          await sendInstagramDM(pageToken, senderId, rule.response);
          // hit count
          if (rule.id) {
            try {
              const { prisma } = await import("@/lib/prisma");
              await prisma.dmRule.update({
                where: { id: rule.id },
                data: { hitCount: { increment: 1 } },
              });
            } catch {
              /* */
            }
          }
        } catch (err) {
          console.error("Failed to send IG DM reply:", err);
        }
      }
    }

    return NextResponse.json({ status: "ok" });
  } catch (error: any) {
    console.error("Webhook error:", error);
    // Meta انتظار 200 دارد تا retry نکند
    return NextResponse.json({ status: "error", message: error.message });
  }
}
