import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { publishInstagramPhoto, publishInstagramReel } from "@/lib/instagram";
import { z } from "zod";

const schema = z.object({
  accountId: z.string().optional(),
  caption: z.string().min(1),
  imageUrl: z.string().url().optional(),
  videoUrl: z.string().url().optional(),
  type: z.enum(["photo", "reel"]).default("photo"),
});

/**
 * انتشار مستقیم روی اینستاگرام
 * imageUrl/videoUrl باید از اینترنت عمومی برای سرورهای Meta قابل دسترس باشد
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    if (data.type === "photo" && !data.imageUrl) {
      return NextResponse.json({ error: "imageUrl برای عکس لازم است" }, { status: 400 });
    }
    if (data.type === "reel" && !data.videoUrl) {
      return NextResponse.json({ error: "videoUrl برای ریلز لازم است" }, { status: 400 });
    }

    let accessToken = process.env.INSTAGRAM_ACCESS_TOKEN;
    let igUserId = process.env.INSTAGRAM_IG_USER_ID;

    if (data.accountId) {
      try {
        const account = await prisma.socialAccount.findUnique({
          where: { id: data.accountId },
        });
        if (account?.platform === "instagram") {
          accessToken = account.accessToken || accessToken;
          igUserId = account.platformUserId || igUserId;
        }
      } catch {
        /* DB optional */
      }
    }

    if (!accessToken || !igUserId) {
      return NextResponse.json(
        {
          error: "توکن یا IG User ID تنظیم نشده",
          hint: "از صفحه اکانت‌ها اینستاگرام را وصل کنید یا متغیرهای INSTAGRAM_* را در .env بگذارید",
        },
        { status: 400 }
      );
    }

    const result =
      data.type === "reel"
        ? await publishInstagramReel(accessToken, igUserId, data.videoUrl!, data.caption)
        : await publishInstagramPhoto(accessToken, igUserId, data.imageUrl!, data.caption);

    return NextResponse.json({
      success: true,
      mediaId: result.id,
      message: "با موفقیت در اینستاگرام منتشر شد",
    });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "داده نامعتبر", details: error.errors }, { status: 400 });
    }
    return NextResponse.json(
      {
        error: error.message,
        hint: "URL تصویر/ویدیو باید عمومی باشد (نه localhost).",
      },
      { status: 500 }
    );
  }
}
