import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { validateInstagramToken, INSTAGRAM_SETUP_STEPS } from "@/lib/instagram";
import { z } from "zod";

const schema = z.object({
  accessToken: z.string().min(10),
  igUserId: z.string().min(1),
  displayName: z.string().optional(),
});

/** اتصال / اعتبارسنجی اکانت اینستاگرام و ذخیره در دیتابیس */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    const result = await validateInstagramToken(data.accessToken, data.igUserId);

    if (!result.ok || !result.account) {
      return NextResponse.json(
        {
          success: false,
          error: result.error || "توکن یا آی‌دی نامعتبر است",
          steps: INSTAGRAM_SETUP_STEPS,
        },
        { status: 400 }
      );
    }

    const acc = result.account;

    let user = await prisma.user.findFirst();
    if (!user) {
      user = await prisma.user.create({
        data: { name: "مدیر", email: "admin@socialgrow.local" },
      });
    }

    const existing = await prisma.socialAccount.findFirst({
      where: {
        platform: "instagram",
        OR: [{ platformUserId: acc.id }, { username: acc.username }],
      },
    });

    let account;
    if (existing) {
      account = await prisma.socialAccount.update({
        where: { id: existing.id },
        data: {
          username: acc.username,
          displayName: data.displayName || acc.name || acc.username,
          avatarUrl: acc.profile_picture_url,
          followers: acc.followers_count || 0,
          connected: true,
          accessToken: data.accessToken,
          platformUserId: acc.id,
          lastSyncAt: new Date(),
        },
      });
    } else {
      account = await prisma.socialAccount.create({
        data: {
          platform: "instagram",
          username: acc.username,
          displayName: data.displayName || acc.name || acc.username,
          avatarUrl: acc.profile_picture_url,
          followers: acc.followers_count || 0,
          connected: true,
          accessToken: data.accessToken,
          platformUserId: acc.id,
          lastSyncAt: new Date(),
          userId: user.id,
        },
      });
    }

    return NextResponse.json({
      success: true,
      account: {
        id: account.id,
        platform: "instagram",
        username: account.username,
        displayName: account.displayName,
        followers: account.followers,
        connected: true,
        avatarUrl: account.avatarUrl,
      },
      instagram: {
        id: acc.id,
        username: acc.username,
        followers_count: acc.followers_count,
        media_count: acc.media_count,
      },
      message: `اکانت @${acc.username} با موفقیت متصل شد`,
    });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "توکن و IG User ID الزامی است" }, { status: 400 });
    }
    return NextResponse.json({ error: error.message, steps: INSTAGRAM_SETUP_STEPS }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    steps: INSTAGRAM_SETUP_STEPS,
    env: {
      INSTAGRAM_APP_ID: !!process.env.INSTAGRAM_APP_ID,
      INSTAGRAM_APP_SECRET: !!process.env.INSTAGRAM_APP_SECRET,
    },
    docs: "https://developers.facebook.com/docs/instagram-platform",
  });
}
