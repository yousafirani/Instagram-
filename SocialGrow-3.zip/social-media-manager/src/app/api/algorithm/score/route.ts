import { NextRequest, NextResponse } from "next/server";
import {
  scoreContent,
  analyzeCaption,
  ALGORITHM_GUIDE,
  type IgSurface,
} from "@/lib/instagram-algorithm";
import { z } from "zod";

const schema = z.object({
  caption: z.string().min(1),
  hasVideo: z.boolean().optional(),
  hasCarousel: z.boolean().optional(),
  estimatedDurationSec: z.number().optional(),
  surface: z.enum(["feed", "reels", "stories", "explore"]).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const analyzed = analyzeCaption(data.caption);

    const report = scoreContent(
      {
        caption: data.caption,
        hasVideo: data.hasVideo ?? false,
        hasCarousel: data.hasCarousel ?? false,
        estimatedDurationSec: data.estimatedDurationSec,
        hasQuestionCTA: analyzed.hasQuestion,
        hasSaveableValue: analyzed.hasSaveable,
        hasHookInFirstLines: analyzed.hasHook,
      },
      (data.surface as IgSurface) || "reels"
    );

    return NextResponse.json({
      success: true,
      report,
      analyzed,
      guide: ALGORITHM_GUIDE,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    guide: ALGORITHM_GUIDE,
    message:
      "POST با caption برای امتیازدهی. دایرکت انبوه به فالوورها پشتیبانی نمی‌شود.",
  });
}
