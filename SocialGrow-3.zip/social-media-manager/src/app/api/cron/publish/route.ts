import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * Cron: پست‌های زمان‌رسیده را published می‌کند
 * روی Vercel هر دقیقه — بدون نیاز به Redis یا سرور گوشی
 */
export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization");
  const secret = process.env.CRON_SECRET;
  if (secret && auth !== `Bearer ${secret}`) {
    if (process.env.NODE_ENV === "production") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const due = await prisma.post.findMany({
      where: {
        status: "scheduled",
        scheduledAt: { lte: new Date() },
      },
      take: 20,
    });

    for (const post of due) {
      await prisma.post.update({
        where: { id: post.id },
        data: {
          status: "published",
          publishedAt: new Date(),
        },
      });
    }

    return NextResponse.json({
      success: true,
      published: due.length,
      ids: due.map((p) => p.id),
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message,
        hint: "دیتابیس ابری (Postgres) را وصل کنید",
      },
      { status: 500 }
    );
  }
}
