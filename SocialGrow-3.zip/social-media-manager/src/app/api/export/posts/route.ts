import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/** خروجی CSV پست‌ها برای گزارش */
export async function GET() {
  try {
    const posts = await prisma.post.findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
    });

    const header = "id,status,platforms,scheduledAt,publishedAt,content_preview,createdAt\n";
    const rows = posts
      .map((p) => {
        const preview = p.content.replace(/"/g, '""').replace(/\n/g, " ").slice(0, 120);
        return [
          p.id,
          p.status,
          `"${p.platforms}"`,
          p.scheduledAt?.toISOString() || "",
          p.publishedAt?.toISOString() || "",
          `"${preview}"`,
          p.createdAt.toISOString(),
        ].join(",");
      })
      .join("\n");

    const csv = "\uFEFF" + header + rows; // BOM for Excel/Farsi

    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="socialgrow-posts.csv"',
      },
    });
  } catch (error: any) {
    // fallback mock CSV if DB not ready
    const csv =
      "\uFEFF" +
      "id,status,platforms,content_preview\n" +
      'demo1,published,"instagram,twitter","نمونه پست — دیتابیس را با db:setup راه‌اندازی کنید"\n';
    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="socialgrow-posts.csv"',
      },
    });
  }
}
