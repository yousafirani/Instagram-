import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { mockPosts } from "@/lib/mock-data";
import { z } from "zod";

function safeParse(val: string | null | undefined, fallback: unknown) {
  if (!val) return fallback;
  try {
    return JSON.parse(val);
  } catch {
    return fallback;
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");

    const posts = await prisma.post.findMany({
      where: status && status !== "all" ? { status } : undefined,
      include: {
        accounts: { include: { account: true } },
        comments: true,
      },
      orderBy: { createdAt: "desc" },
    });

    const formatted = posts.map((p) => ({
      ...p,
      platforms: safeParse(p.platforms, []),
      mediaUrls: safeParse(p.mediaUrls, []),
      engagement: safeParse(p.engagement, null),
      scheduledAt: p.scheduledAt?.toISOString() ?? null,
      publishedAt: p.publishedAt?.toISOString() ?? null,
      createdAt: p.createdAt.toISOString(),
    }));

    if (formatted.length === 0 && (!status || status === "all")) {
      return NextResponse.json({ success: true, posts: mockPosts, source: "mock" });
    }

    return NextResponse.json({ success: true, posts: formatted, source: "database" });
  } catch {
    const status = new URL(req.url).searchParams.get("status");
    const posts =
      status && status !== "all"
        ? mockPosts.filter((p) => p.status === status)
        : mockPosts;
    return NextResponse.json({ success: true, posts, source: "mock" });
  }
}

const createSchema = z.object({
  content: z.string().min(1),
  platforms: z.array(z.string()).min(1),
  accountIds: z.array(z.string()).optional(),
  scheduledAt: z.string().optional().nullable(),
  mediaUrls: z.array(z.string()).optional(),
  status: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    let user = await prisma.user.findFirst();
    if (!user) {
      user = await prisma.user.create({
        data: { name: "مدیر", email: "admin@socialgrow.local" },
      });
    }

    const status =
      data.status ||
      (data.scheduledAt ? "scheduled" : "draft");

    const post = await prisma.post.create({
      data: {
        content: data.content,
        platforms: JSON.stringify(data.platforms),
        mediaUrls: data.mediaUrls ? JSON.stringify(data.mediaUrls) : null,
        status,
        scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : null,
        publishedAt: status === "published" ? new Date() : null,
        userId: user.id,
      },
    });

    return NextResponse.json({
      success: true,
      post: {
        ...post,
        platforms: data.platforms,
        mediaUrls: data.mediaUrls || [],
      },
    });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "داده نامعتبر", details: error.errors }, { status: 400 });
    }
    return NextResponse.json({
      success: true,
      post: {
        id: `local_${Date.now()}`,
        content: "saved-offline",
        status: "draft",
      },
      warning: "دیتابیس در دسترس نبود — برای ذخیره پایدار npm run db:setup را اجرا کنید",
      details: error.message,
    });
  }
}
