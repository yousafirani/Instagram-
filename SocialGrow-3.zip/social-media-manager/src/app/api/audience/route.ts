import { NextRequest, NextResponse } from "next/server";
import {
  generateAudienceInsights,
  generateContentSuggestions,
  type TargetingCriteria,
  type InterestCategory,
} from "@/lib/audience-targeting";
import { z } from "zod";

const schema = z.object({
  interests: z.array(z.string()).min(1),
  locations: z.array(z.string()).optional(),
  platforms: z.array(z.string()).optional(),
  contentType: z.enum(["image", "video", "carousel", "text"]).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    const criteria: TargetingCriteria = {
      interests: data.interests as InterestCategory[],
      locations: data.locations,
      contentType: data.contentType,
    };

    const insights = generateAudienceInsights(criteria);
    const platform = data.platforms?.[0] || "instagram";
    const suggestions = generateContentSuggestions(criteria, platform);

    return NextResponse.json({
      success: true,
      insights,
      suggestions,
      message: "پیشنهادها فقط برای تولید محتوای بهتر است – نه برای فالو اجباری یا اسپم.",
    });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "معیارها نامعتبر است", details: error.errors }, { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
