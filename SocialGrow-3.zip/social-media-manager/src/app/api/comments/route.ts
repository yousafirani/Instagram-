import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { mockComments } from "@/lib/mock-data";
import { z } from "zod";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const replied = searchParams.get("replied");

    const comments = await prisma.comment.findMany({
      where:
        replied === "true"
          ? { replied: true }
          : replied === "false"
          ? { replied: false }
          : undefined,
      orderBy: { createdAt: "desc" },
      include: { post: { select: { content: true, id: true } } },
    });

    if (comments.length === 0) {
      let list = mockComments;
      if (replied === "true") list = list.filter((c) => c.replied);
      if (replied === "false") list = list.filter((c) => !c.replied);
      return NextResponse.json({ success: true, comments: list, source: "mock" });
    }

    return NextResponse.json({
      success: true,
      comments: comments.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        authorAvatar:
          c.authorAvatar ||
          `https://api.dicebear.com/7.x/avataaars/svg?seed=${c.author}`,
      })),
      source: "database",
    });
  } catch {
    return NextResponse.json({ success: true, comments: mockComments, source: "mock" });
  }
}

const replySchema = z.object({
  commentId: z.string(),
  replyContent: z.string().min(1),
});

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const data = replySchema.parse(body);

    const comment = await prisma.comment.update({
      where: { id: data.commentId },
      data: {
        replied: true,
        replyContent: data.replyContent,
        repliedAt: new Date(),
      },
    });

    return NextResponse.json({ success: true, comment });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "داده نامعتبر" }, { status: 400 });
    }
    return NextResponse.json({
      success: true,
      mocked: true,
      message: "پاسخ ثبت شد (حالت آزمایشی بدون دیتابیس)",
      details: error.message,
    });
  }
}
