import { NextRequest, NextResponse } from "next/server";
import { suggestCommentReply } from "@/lib/ai";
import { z } from "zod";

const schema = z.object({
  comment: z.string().min(1),
  postContent: z.string().optional(),
  platform: z.string().default("instagram"),
  brandTone: z.enum(["friendly", "professional", "casual", "humorous"]).optional(),
  language: z.enum(["fa", "en"]).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    const suggestion = await suggestCommentReply({
      comment: data.comment,
      postContent: data.postContent,
      platform: data.platform,
      brandTone: data.brandTone,
      language: data.language || "fa",
    });

    return NextResponse.json({
      success: true,
      suggestion,
      isMock: !process.env.XAI_API_KEY && !process.env.OPENAI_API_KEY,
    });
  } catch (error: any) {
    console.error("Suggest reply error:", error);
    return NextResponse.json(
      { error: "خطا در تولید پیشنهاد", details: error.message },
      { status: 500 }
    );
  }
}
