import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { mockAccounts } from "@/lib/mock-data";
import { z } from "zod";

export async function GET() {
  try {
    const accounts = await prisma.socialAccount.findMany({
      orderBy: { createdAt: "desc" },
    });
    if (accounts.length === 0) {
      return NextResponse.json({ success: true, accounts: mockAccounts, source: "mock" });
    }
    return NextResponse.json({ success: true, accounts, source: "database" });
  } catch {
    return NextResponse.json({ success: true, accounts: mockAccounts, source: "mock" });
  }
}

const createSchema = z.object({
  platform: z.enum([
    "instagram",
    "twitter",
    "linkedin",
    "tiktok",
    "youtube",
    "telegram",
    "eitaa",
    "bale",
  ]),
  username: z.string().min(1),
  displayName: z.string().optional(),
  avatarUrl: z.string().optional(),
  followers: z.number().optional(),
  accessToken: z.string().optional(),
  platformUserId: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = createSchema.parse(body);

    let user = await prisma.user.findFirst();
    if (!user) {
      user = await prisma.user.create({
        data: { name: "مدیر", email: "admin@socialgrow.local" },
      });
    }

    const account = await prisma.socialAccount.create({
      data: {
        platform: data.platform,
        username: data.username,
        displayName: data.displayName || data.username,
        avatarUrl:
          data.avatarUrl ||
          `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.username}`,
        followers: data.followers || 0,
        connected: true,
        accessToken: data.accessToken,
        platformUserId: data.platformUserId,
        userId: user.id,
      },
    });

    return NextResponse.json({ success: true, account });
  } catch (error: any) {
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "داده نامعتبر", details: error.errors }, { status: 400 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
