import { NextRequest, NextResponse } from "next/server";
import { schedulePost, publishNow } from "@/lib/queue";
import { z } from "zod";

const schema = z.object({
  content: z.string().min(1).max(5000),
  platforms: z.array(z.string()).min(1),
  accountIds: z.array(z.string()).optional(),
  scheduledAt: z.string().optional(),
  mediaUrls: z.array(z.string()).optional(),
  publishImmediately: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    const jobData = {
      postId: `post_${Date.now()}`,
      content: data.content,
      platforms: data.platforms,
      accountIds: data.accountIds || [],
      mediaUrls: data.mediaUrls,
      accessTokens: {},
    };

    let job;
    if (data.publishImmediately || !data.scheduledAt) {
      job = await publishNow(jobData);
    } else {
      const scheduledDate = new Date(data.scheduledAt);
      if (isNaN(scheduledDate.getTime()) || scheduledDate.getTime() < Date.now() - 60000) {
        return NextResponse.json(
          { error: "زمان زمان‌بندی معتبر نیست" },
          { status: 400 }
        );
      }
      job = await schedulePost(jobData, scheduledDate);
    }

    return NextResponse.json({
      success: true,
      jobId: job.id,
      postId: jobData.postId,
      mode: (job as any).mode || "redis",
      message:
        data.publishImmediately || !data.scheduledAt
          ? "پست برای انتشار ثبت شد"
          : "پست زمان‌بندی شد",
    });
  } catch (error: any) {
    console.error("Schedule error:", error);
    if (error.name === "ZodError") {
      return NextResponse.json(
        { error: "داده‌های نامعتبر", details: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json({
      success: true,
      jobId: `fallback_${Date.now()}`,
      mode: "database",
      message: "پست در دیتابیس ذخیره شد. انتشار با Cron انجام می‌شود.",
      warning: error.message,
    });
  }
}
