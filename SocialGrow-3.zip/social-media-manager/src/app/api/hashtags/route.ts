import { NextRequest, NextResponse } from "next/server";
import { listHashtagPacks, addHashtagPack } from "@/lib/hashtag-packs";
import { z } from "zod";

export async function GET() {
  return NextResponse.json({ success: true, packs: listHashtagPacks() });
}

const schema = z.object({
  name: z.string().min(1),
  category: z.string().default("سفارشی"),
  tags: z.array(z.string()).min(1),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const tags = data.tags.map((t) => (t.startsWith("#") ? t : `#${t}`));
    const pack = addHashtagPack({
      name: data.name,
      category: data.category,
      tags,
    });
    return NextResponse.json({ success: true, pack });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
