import { NextRequest, NextResponse } from "next/server";
import {
  getAutomationSettings,
  updateAutomationSettings,
  DEFAULT_AUTOMATION,
} from "@/lib/automation";
import { z } from "zod";

export async function GET() {
  return NextResponse.json({
    success: true,
    settings: getAutomationSettings(),
    defaults: DEFAULT_AUTOMATION,
  });
}

const schema = z.object({
  autoReplyComments: z.boolean().optional(),
  autoReplyDelayMinutes: z.number().min(1).max(120).optional(),
  autoReplyOnlyQuestions: z.boolean().optional(),
  autoHashtags: z.boolean().optional(),
  autoBestTime: z.boolean().optional(),
  maxAutoRepliesPerHour: z.number().min(1).max(50).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const settings = updateAutomationSettings(data);
    return NextResponse.json({
      success: true,
      settings,
      message: "تنظیمات اتوماسیون ذخیره شد",
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
