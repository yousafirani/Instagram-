import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  getAutomationSettings,
  generateAutoReply,
  looksLikeQuestion,
} from "@/lib/automation";
import { z } from "zod";

/**
 * پردازش پاسخ خودکار برای کامنت‌های بدون پاسخ
 * فقط کامنت‌های زیر پست‌های خودتان – با رعایت تنظیمات
 */
export async function POST(req: NextRequest) {
  try {
    const settings = getAutomationSettings();
    if (!settings.autoReplyComments) {
      return NextResponse.json({
        success: false,
        message: "پاسخ خودکار خاموش است. از تنظیمات فعال کنید.",
        processed: 0,
      });
    }

    const body = await req.json().catch(() => ({}));
    const limit = Math.min(body.limit || 5, settings.maxAutoRepliesPerHour);

    const pending = await prisma.comment.findMany({
      where: { replied: false },
      take: limit,
      orderBy: { createdAt: "asc" },
      include: { post: { select: { content: true } } },
    });

    const results: { id: string; replied: boolean; reply?: string; skipped?: string }[] = [];

    for (const comment of pending) {
      if (settings.autoReplyOnlyQuestions && !looksLikeQuestion(comment.content)) {
        results.push({ id: comment.id, replied: false, skipped: "سؤال نیست" });
        continue;
      }

      const reply = await generateAutoReply(
        comment.content,
        comment.post?.content || "",
        comment.platform,
        settings
      );

      if (!reply) {
        results.push({ id: comment.id, replied: false, skipped: "پاسخی تولید نشد" });
        continue;
      }

      await prisma.comment.update({
        where: { id: comment.id },
        data: {
          replied: true,
          replyContent: reply,
          repliedAt: new Date(),
        },
      });

      results.push({ id: comment.id, replied: true, reply });
    }

    const repliedCount = results.filter((r) => r.replied).length;

    return NextResponse.json({
      success: true,
      processed: repliedCount,
      total: pending.length,
      results,
      message:
        repliedCount > 0
          ? `${repliedCount} کامنت با AI پاسخ داده شد (تأخیر پیشنهادی: ${settings.autoReplyDelayMinutes} دقیقه برای طبیعی‌تر بودن)`
          : "کامنتی برای پاسخ خودکار یافت نشد یا تنظیمات محدودکننده فعال است",
      disclaimer:
        "پاسخ‌ها فقط برای کامنت‌های زیر پست‌های شماست. قبل از اتکای کامل، چند مورد را دستی بررسی کنید.",
    });
  } catch (error: any) {
    // اگر دیتابیس نباشد، با پیام واضح برمی‌گردیم
    return NextResponse.json(
      {
        error: error.message,
        hint: "ابتدا npm run db:setup را اجرا کنید",
      },
      { status: 500 }
    );
  }
}
