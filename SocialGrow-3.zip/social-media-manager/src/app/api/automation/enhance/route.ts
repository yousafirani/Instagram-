import { NextRequest, NextResponse } from "next/server";
import { enhanceCaption, suggestBestTimes, getAutomationSettings } from "@/lib/automation";
import { getTemplate, type PostType, CONTENT_TEMPLATES } from "@/lib/content-templates";
import { z } from "zod";

const schema = z.object({
  caption: z.string().optional(),
  templateId: z.string().optional(),
  platforms: z.array(z.string()).optional(),
  applyHashtags: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const settings = getAutomationSettings();

    let caption = data.caption || "";
    let templateHashtags: string[] = [];
    let templateMeta = null;

    if (data.templateId) {
      const t = getTemplate(data.templateId as PostType);
      if (t) {
        if (!caption.trim()) caption = t.captionTemplate;
        templateHashtags = t.hashtags;
        templateMeta = {
          id: t.id,
          title: t.title,
          mediaHint: t.mediaHint,
          bestTimes: t.bestTimes,
        };
      }
    }

    const applyHashtags = data.applyHashtags ?? settings.autoHashtags;
    const enhanced = enhanceCaption(caption, {
      autoHashtags: applyHashtags,
      templateHashtags,
    });

    const bestTimes =
      settings.autoBestTime && data.platforms?.length
        ? suggestBestTimes(data.platforms)
        : templateMeta?.bestTimes || [];

    return NextResponse.json({
      success: true,
      caption: enhanced.caption,
      hashtags: enhanced.hashtags,
      bestTimes,
      template: templateMeta,
      templates: CONTENT_TEMPLATES.map((t) => ({
        id: t.id,
        title: t.title,
        description: t.description,
        mediaHint: t.mediaHint,
      })),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    templates: CONTENT_TEMPLATES.map((t) => ({
      id: t.id,
      title: t.title,
      description: t.description,
      platforms: t.platforms,
      hashtags: t.hashtags,
      bestTimes: t.bestTimes,
      mediaHint: t.mediaHint,
      captionTemplate: t.captionTemplate,
    })),
  });
}
