import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  mockAnalytics,
  mockPlatformStats,
  mockPosts,
  mockComments,
  mockAccounts,
} from "@/lib/mock-data";

export async function GET() {
  try {
    const [posts, comments, accounts] = await Promise.all([
      prisma.post.findMany({
        orderBy: { createdAt: "desc" },
        take: 20,
      }),
      prisma.comment.findMany({
        orderBy: { createdAt: "desc" },
        take: 20,
      }),
      prisma.socialAccount.findMany({
        orderBy: { createdAt: "desc" },
      }),
    ]);

    const formattedPosts = posts.map((p) => ({
      ...p,
      platforms: safeParse(p.platforms, []),
      mediaUrls: safeParse(p.mediaUrls, []),
      engagement: safeParse(p.engagement, null),
      scheduledAt: p.scheduledAt?.toISOString() ?? null,
      publishedAt: p.publishedAt?.toISOString() ?? null,
      createdAt: p.createdAt.toISOString(),
    }));

    const totalFollowers = accounts.reduce((s, a) => s + (a.followers || 0), 0);
    const scheduled = posts.filter((p) => p.status === "scheduled").length;
    const published = posts.filter((p) => p.status === "published").length;
    const pendingComments = comments.filter((c) => !c.replied).length;

    const platformMap = new Map<string, { followers: number; posts: number }>();
    for (const a of accounts) {
      const cur = platformMap.get(a.platform) || { followers: 0, posts: 0 };
      cur.followers += a.followers || 0;
      platformMap.set(a.platform, cur);
    }
    for (const p of posts) {
      const plats = safeParse(p.platforms, []) as string[];
      for (const pl of plats) {
        const cur = platformMap.get(pl) || { followers: 0, posts: 0 };
        cur.posts += 1;
        platformMap.set(pl, cur);
      }
    }

    const platformStats = Array.from(platformMap.entries()).map(([platform, v]) => ({
      platform,
      followers: v.followers,
      engagementRate: 4 + Math.random() * 3,
      posts: v.posts,
      growth: 2 + Math.random() * 4,
    }));

    return NextResponse.json({
      success: true,
      source: "database",
      analytics: {
        totalFollowers: totalFollowers || mockAnalytics.totalFollowers,
        followerGrowth: mockAnalytics.followerGrowth,
        totalEngagement: mockAnalytics.totalEngagement,
        engagementRate: mockAnalytics.engagementRate,
        postsThisWeek: published + scheduled,
        bestPerformingPost: formattedPosts[0]?.content?.slice(0, 60) || mockAnalytics.bestPerformingPost,
      },
      platformStats: platformStats.length ? platformStats : mockPlatformStats,
      posts: formattedPosts.length ? formattedPosts : mockPosts,
      comments: comments.length
        ? comments.map((c) => ({
            ...c,
            createdAt: c.createdAt.toISOString(),
            authorAvatar: c.authorAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${c.author}`,
          }))
        : mockComments,
      accounts: accounts.length ? accounts : mockAccounts,
      meta: { scheduled, published, pendingComments },
    });
  } catch {
    return NextResponse.json({
      success: true,
      source: "mock",
      analytics: mockAnalytics,
      platformStats: mockPlatformStats,
      posts: mockPosts,
      comments: mockComments,
      accounts: mockAccounts,
      meta: {
        scheduled: mockPosts.filter((p) => p.status === "scheduled").length,
        published: mockPosts.filter((p) => p.status === "published").length,
        pendingComments: mockComments.filter((c) => !c.replied).length,
      },
    });
  }
}

function safeParse(val: string | null | undefined, fallback: unknown) {
  if (!val) return fallback;
  try {
    return JSON.parse(val);
  } catch {
    return fallback;
  }
}
