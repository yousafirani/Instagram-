import { NextResponse } from "next/server";
import {
  generateMockFollowers,
  analyzeAll,
  type FollowerAnalysisResult,
} from "@/lib/follower-analysis";

/**
 * گزارش تشخیص فالوور مشکوک
 * فقط تحلیلی – هیچ حذف یا بلاکی انجام نمی‌شود
 */
export async function GET() {
  try {
    // در نسخه واقعی: از API پلتفرم (Instagram Graph / X) لیست فالوورها گرفته می‌شود
    const followers = generateMockFollowers(45);
    const results: FollowerAnalysisResult[] = analyzeAll(followers);

    const summary = {
      total: results.length,
      critical: results.filter((r) => r.suspicion.level === "critical").length,
      high: results.filter((r) => r.suspicion.level === "high").length,
      medium: results.filter((r) => r.suspicion.level === "medium").length,
      low: results.filter((r) => r.suspicion.level === "low").length,
      avgScore: Math.round(
        results.reduce((s, r) => s + r.suspicion.score, 0) / results.length
      ),
    };

    return NextResponse.json({
      success: true,
      summary,
      results,
      disclaimer:
        "این گزارش صرفاً تحلیلی است. هیچ فالووری به‌صورت خودکار حذف یا بلاک نمی‌شود. تصمیم نهایی با شماست.",
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
