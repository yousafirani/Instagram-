import { NextRequest, NextResponse } from "next/server";
import {
  listMemoryRules,
  upsertMemoryRule,
  deleteMemoryRule,
  setMemoryRules,
  DEFAULT_DM_RULES,
} from "@/lib/dm-rules";
import { z } from "zod";

async function loadFromDb() {
  try {
    const { prisma } = await import("@/lib/prisma");
    const rows = await prisma.dmRule.findMany({ orderBy: { priority: "desc" } });
    if (rows.length) {
      setMemoryRules(
        rows.map((r) => ({
          id: r.id,
          platform: r.platform,
          keyword: r.keyword,
          matchType: (r.matchType as "exact" | "contains") || "contains",
          response: r.response,
          active: r.active,
          priority: r.priority,
          hitCount: r.hitCount,
        }))
      );
    }
  } catch {
    /* mock memory */
  }
}

export async function GET() {
  await loadFromDb();
  return NextResponse.json({
    success: true,
    rules: listMemoryRules(),
    defaults: DEFAULT_DM_RULES,
    note: "پاسخ فقط وقتی مخاطب خودش دایرکت می‌دهد ارسال می‌شود.",
  });
}

const schema = z.object({
  id: z.string().optional(),
  keyword: z.string().min(1),
  response: z.string().min(1),
  matchType: z.enum(["exact", "contains"]).optional(),
  active: z.boolean().optional(),
  priority: z.number().optional(),
  platform: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);
    const rule = upsertMemoryRule(data);

    try {
      const { prisma } = await import("@/lib/prisma");
      if (data.id) {
        await prisma.dmRule.upsert({
          where: { id: data.id },
          create: {
            id: rule.id,
            keyword: rule.keyword,
            response: rule.response,
            matchType: rule.matchType || "contains",
            active: rule.active !== false,
            priority: rule.priority || 0,
            platform: rule.platform || "instagram",
          },
          update: {
            keyword: rule.keyword,
            response: rule.response,
            matchType: rule.matchType || "contains",
            active: rule.active !== false,
            priority: rule.priority || 0,
          },
        });
      } else {
        const created = await prisma.dmRule.create({
          data: {
            keyword: rule.keyword,
            response: rule.response,
            matchType: rule.matchType || "contains",
            active: rule.active !== false,
            priority: rule.priority || 0,
            platform: rule.platform || "instagram",
          },
        });
        rule.id = created.id;
      }
    } catch {
      /* memory only */
    }

    return NextResponse.json({ success: true, rule });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}

export async function DELETE(req: NextRequest) {
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id لازم است" }, { status: 400 });
  deleteMemoryRule(id);
  try {
    const { prisma } = await import("@/lib/prisma");
    await prisma.dmRule.delete({ where: { id } }).catch(() => null);
  } catch {
    /* */
  }
  return NextResponse.json({ success: true });
}
