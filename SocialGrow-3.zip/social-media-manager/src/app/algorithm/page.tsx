"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Loader2, Gauge, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function AlgorithmPage() {
  const [caption, setCaption] = useState("");
  const [surface, setSurface] = useState("reels");
  const [hasVideo, setHasVideo] = useState(true);
  const [duration, setDuration] = useState(20);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<any>(null);
  const [error, setError] = useState("");

  const run = async () => {
    if (!caption.trim()) {
      setError("کپشن را وارد کنید");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/algorithm/score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caption,
          surface,
          hasVideo,
          estimatedDurationSec: duration,
          hasCarousel: false,
        }),
      });
      const data = await res.json();
      if (data.success) setReport(data.report);
      else setError(data.error || "خطا");
    } catch {
      setError("خطا در ارتباط با سرور");
    } finally {
      setLoading(false);
    }
  };

  const gradeColor: Record<string, string> = {
    A: "text-emerald-600 bg-emerald-50",
    B: "text-blue-600 bg-blue-50",
    C: "text-amber-600 bg-amber-50",
    D: "text-red-600 bg-red-50",
  };

  return (
    <>
      <Header title="الگوریتم اینستاگرام" />
      <div className="space-y-6 p-8 max-w-4xl">
        <Card className="border-indigo-200 bg-indigo-50/40">
          <CardContent className="p-4 text-sm text-indigo-900">
            <p className="font-medium">سه سیگنال اصلی (Mosseri):</p>
            <p className="mt-1 text-xs">
              زمان تماشا · لایک نسبت به بازدید · ارسال در دایرکت — برای رشد، Send و
              تکمیل ریلز حیاتی‌اند. این صفحه محتوا را قبل از انتشار امتیاز می‌دهد.
            </p>
          </CardContent>
        </Card>

        <Card className="border-red-200 bg-red-50/50">
          <CardContent className="flex gap-3 p-4 text-sm text-red-800">
            <AlertTriangle className="h-5 w-5 shrink-0" />
            <div>
              <p className="font-medium">دایرکت خودکار به همه فالوورها وجود ندارد</p>
              <p className="mt-1 text-xs">
                ارسال خودکار پست به پیوی فالوورها اسپم است و خلاف قوانین اینستاگرام،
                تلگرام، ایتا و بله است. برنامه فقط انتشار در فید/کانال و پاسخ به
                کامنت‌های پست خودتان را پشتیبانی می‌کند.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Gauge className="h-5 w-5" />
              امتیازدهی کپشن / ریلز
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {(
                [
                  ["reels", "ریلز"],
                  ["feed", "فید"],
                  ["stories", "استوری"],
                  ["explore", "اکسپلور"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSurface(id)}
                  className={`rounded-lg px-3 py-1.5 text-sm font-medium ${
                    surface === id
                      ? "bg-indigo-600 text-white"
                      : "bg-gray-100 text-gray-600"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <textarea
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              rows={5}
              placeholder="کپشن یا متن ریلز را اینجا بگذارید..."
              className="w-full rounded-lg border border-gray-200 p-3 text-sm dark:border-gray-700 dark:bg-gray-900"
            />
            <div className="flex flex-wrap gap-4 text-sm">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={hasVideo}
                  onChange={(e) => setHasVideo(e.target.checked)}
                />
                ویدیو / ریلز
              </label>
              <label className="flex items-center gap-2">
                مدت (ثانیه)
                <input
                  type="number"
                  min={5}
                  max={180}
                  value={duration}
                  onChange={(e) => setDuration(Number(e.target.value) || 20)}
                  className="w-20 rounded border px-2 py-1"
                />
              </label>
            </div>
            <Button onClick={run} disabled={loading} className="gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              محاسبه امتیاز الگوریتم
            </Button>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </CardContent>
        </Card>

        {report && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">نتیجه — {report.surface}</CardTitle>
                <span
                  className={`rounded-full px-3 py-1 text-sm font-bold ${
                    gradeColor[report.grade] || ""
                  }`}
                >
                  {report.grade} · {report.totalScore}
                </span>
              </div>
              <p className="text-sm text-gray-500">{report.summary}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {report.signals?.map((s: any) => (
                <div key={s.name}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">{s.nameFa}</span>
                    <span>{s.score}</span>
                  </div>
                  <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-indigo-500"
                      style={{ width: `${s.score}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-gray-500">{s.tip}</p>
                </div>
              ))}
              <div>
                <p className="text-sm font-medium mb-2">پیشنهادها</p>
                <ul className="space-y-1">
                  {report.recommendations?.map((r: string, i: number) => (
                    <li key={i} className="flex gap-2 text-sm text-gray-700">
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}
