"use client";

import Header from "@/components/layout/Header";
import StatsCards from "@/components/dashboard/StatsCards";
import PlatformOverview from "@/components/dashboard/PlatformOverview";
import RecentPosts from "@/components/dashboard/RecentPosts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, Clock, Loader2, Sparkles } from "lucide-react";
import { formatDate, platformLabel } from "@/lib/utils";
import Link from "next/link";
import { useEffect, useState } from "react";

export default function DashboardPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <>
        <Header title="داشبورد" />
        <div className="flex justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
        </div>
      </>
    );
  }

  const analytics = data?.analytics;
  const posts = data?.posts || [];
  const comments = data?.comments || [];
  const platformStats = data?.platformStats || [];
  const pendingComments = comments.filter((c: any) => !c.replied);
  const upcomingPosts = posts.filter((p: any) => p.status === "scheduled");

  return (
    <>
      <Header title="داشبورد" />
      <div className="space-y-6 p-4 sm:p-8">
        {data?.source === "mock" && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
            حالت نمایشی — برای داده واقعی: <code className="font-mono">npm run db:setup</code>
          </div>
        )}

        {analytics && <StatsCards data={analytics} />}

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Link href="/scheduler" className="rounded-xl border bg-white p-4 text-center shadow-sm dark:bg-gray-950">
            <Sparkles className="mx-auto h-5 w-5 text-indigo-600" />
            <p className="mt-2 text-xs font-medium">زمان‌بندی پست</p>
          </Link>
          <Link href="/comments" className="rounded-xl border bg-white p-4 text-center shadow-sm dark:bg-gray-950">
            <MessageCircle className="mx-auto h-5 w-5 text-emerald-600" />
            <p className="mt-2 text-xs font-medium">کامنت‌ها</p>
          </Link>
          <Link href="/algorithm" className="rounded-xl border bg-white p-4 text-center shadow-sm dark:bg-gray-950">
            <span className="text-lg">📊</span>
            <p className="mt-2 text-xs font-medium">الگوریتم</p>
          </Link>
          <Link href="/growth" className="rounded-xl border bg-white p-4 text-center shadow-sm dark:bg-gray-950">
            <span className="text-lg">🚀</span>
            <p className="mt-2 text-xs font-medium">رشد فالوور</p>
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <RecentPosts posts={posts} />
          </div>

          <div className="space-y-6">
            <PlatformOverview stats={platformStats} />

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <MessageCircle className="h-4 w-4" />
                  کامنت بدون پاسخ
                </CardTitle>
                <Link href="/comments" className="text-xs text-indigo-600 hover:underline">
                  همه
                </Link>
              </CardHeader>
              <CardContent className="space-y-3">
                {pendingComments.length === 0 ? (
                  <p className="text-sm text-gray-400">همه پاسخ داده شده</p>
                ) : (
                  pendingComments.slice(0, 4).map((comment: any) => (
                    <div key={comment.id} className="rounded-lg bg-gray-50 p-3 dark:bg-gray-900">
                      <div className="flex items-center gap-2">
                        <img
                          src={comment.authorAvatar}
                          alt=""
                          className="h-6 w-6 rounded-full"
                        />
                        <span className="text-sm font-medium">{comment.author}</span>
                        <span className="text-xs text-gray-400">
                          {platformLabel(comment.platform)}
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-gray-600 line-clamp-2 dark:text-gray-300">
                        {comment.content}
                      </p>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Clock className="h-4 w-4" />
                  زمان‌بندی‌شده
                </CardTitle>
                <Link href="/calendar" className="text-xs text-indigo-600 hover:underline">
                  تقویم
                </Link>
              </CardHeader>
              <CardContent className="space-y-3">
                {upcomingPosts.length === 0 ? (
                  <p className="text-sm text-gray-400">پستی در صف نیست</p>
                ) : (
                  upcomingPosts.slice(0, 3).map((post: any) => (
                    <div key={post.id} className="rounded-lg bg-gray-50 p-3 dark:bg-gray-900">
                      <p className="text-sm line-clamp-2">{post.content}</p>
                      <p className="mt-1 text-xs text-indigo-600">
                        {post.scheduledAt ? formatDate(post.scheduledAt) : "—"}
                      </p>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
