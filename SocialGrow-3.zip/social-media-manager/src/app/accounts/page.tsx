"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { platformLabel, platformColor, formatNumber } from "@/lib/utils";
import { CheckCircle2, XCircle, RefreshCw, Plus, Loader2, Instagram } from "lucide-react";
import { useState, useEffect } from "react";
import { signIn } from "next-auth/react";

interface Account {
  id: string;
  platform: string;
  username: string;
  displayName: string | null;
  avatarUrl: string | null;
  followers: number;
  connected: boolean;
  lastSyncAt?: string;
}

export default function AccountsPage() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [igToken, setIgToken] = useState("");
  const [igUserId, setIgUserId] = useState("");
  const [igLoading, setIgLoading] = useState(false);
  const [igMessage, setIgMessage] = useState("");
  const [steps, setSteps] = useState<string[]>([]);

  const fetchAccounts = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch("/api/accounts");
      const data = await res.json();
      if (data.success) setAccounts(data.accounts);
      else setError(data.error || "خطا در دریافت اکانت‌ها");
    } catch {
      setError("اتصال به سرور برقرار نشد");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
    fetch("/api/instagram/connect")
      .then((r) => r.json())
      .then((d) => d.steps && setSteps(d.steps))
      .catch(() => {});
  }, []);

  const handleConnectX = () => {
    signIn("twitter", { callbackUrl: "/accounts" });
  };

  const handleConnectInstagram = async () => {
    if (!igToken.trim() || !igUserId.trim()) {
      setIgMessage("توکن و IG User ID را وارد کنید");
      return;
    }
    setIgLoading(true);
    setIgMessage("");
    try {
      const res = await fetch("/api/instagram/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accessToken: igToken.trim(),
          igUserId: igUserId.trim(),
        }),
      });
      const data = await res.json();
      if (data.success) {
        setIgMessage(data.message || "متصل شد");
        setIgToken("");
        setIgUserId("");
        fetchAccounts();
      } else {
        setIgMessage(data.error || "اتصال ناموفق");
        if (data.steps) setSteps(data.steps);
      }
    } catch {
      setIgMessage("خطا در ارتباط با سرور");
    } finally {
      setIgLoading(false);
    }
  };

  return (
    <>
      <Header title="مدیریت اکانت‌ها" />
      <div className="space-y-6 p-4 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              اکانت‌های متصل
            </h2>
            <p className="text-sm text-gray-500">اینستاگرام، X و سایر پلتفرم‌ها</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleConnectX} className="gap-2 bg-black hover:bg-gray-800">
              <Plus className="h-4 w-4" />
              اتصال X
            </Button>
            <Button variant="outline" className="gap-2" onClick={fetchAccounts}>
              <RefreshCw className="h-4 w-4" />
              بروزرسانی
            </Button>
          </div>
        </div>

        {/* Instagram connect */}
        <Card className="border-pink-200 dark:border-pink-900">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Instagram className="h-5 w-5 text-pink-600" />
              اتصال اینستاگرام (Graph API)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              اکانت باید Business یا Creator باشد و به Facebook Page وصل باشد.
              Access Token و Instagram User ID را از Meta Developers بگیرید.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-medium">Access Token</label>
                <input
                  type="password"
                  value={igToken}
                  onChange={(e) => setIgToken(e.target.value)}
                  placeholder="EAAB..."
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium">IG User ID</label>
                <input
                  value={igUserId}
                  onChange={(e) => setIgUserId(e.target.value)}
                  placeholder="17841..."
                  className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                />
              </div>
            </div>
            <Button
              onClick={handleConnectInstagram}
              disabled={igLoading}
              className="gap-2 bg-gradient-to-r from-purple-600 to-pink-500 hover:opacity-90"
            >
              {igLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Instagram className="h-4 w-4" />}
              اتصال و اعتبارسنجی اینستاگرام
            </Button>
            {igMessage && (
              <p className="text-sm text-indigo-700 dark:text-indigo-300">{igMessage}</p>
            )}
            {steps.length > 0 && (
              <ol className="list-decimal space-y-1 pr-5 text-xs text-gray-500">
                {steps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ol>
            )}
            <p className="text-xs text-gray-400">
              مستندات:{" "}
              <a
                href="https://developers.facebook.com/docs/instagram-platform"
                target="_blank"
                rel="noreferrer"
                className="text-indigo-600 underline"
              >
                Instagram Platform
              </a>
            </p>
          </CardContent>
        </Card>

        {loading && (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          </div>
        )}

        {error && (
          <Card className="border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40">
            <CardContent className="p-4 text-sm text-amber-800 dark:text-amber-200">
              {error}
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {accounts.map((account) => (
            <Card key={account.id} className="overflow-hidden">
              <div className={`h-2 ${platformColor(account.platform)}`} />
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <img
                    src={
                      account.avatarUrl ||
                      `https://api.dicebear.com/7.x/avataaars/svg?seed=${account.username}`
                    }
                    alt=""
                    className="h-12 w-12 rounded-full"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium truncate">
                        {account.displayName || account.username}
                      </span>
                      {account.connected ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-gray-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-sm text-gray-500">@{account.username}</p>
                    <p className="mt-1 text-xs text-gray-400">
                      {platformLabel(account.platform)} ·{" "}
                      {formatNumber(account.followers)} فالوور
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </>
  );
}
