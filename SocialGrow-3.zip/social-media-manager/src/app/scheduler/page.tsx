"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { platformLabel, formatDate } from "@/lib/utils";
import {
  Calendar,
  Clock,
  Send,
  Image as ImageIcon,
  Loader2,
  CheckCircle,
  X,
  Sparkles,
  LayoutTemplate,
} from "lucide-react";
import { useState, useEffect, useRef } from "react";

interface ScheduledPost {
  id: string;
  content: string;
  platforms: string[];
  scheduledAt: string | null;
  status: string;
}

interface TemplateItem {
  id: string;
  title: string;
  description: string;
  mediaHint?: string;
}

export default function SchedulerPage() {
  const [content, setContent] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["instagram"]);
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("");
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([]);
  const [uploadedUrls, setUploadedUrls] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [templates, setTemplates] = useState<TemplateItem[]>([]);
  const [bestTimes, setBestTimes] = useState<string[]>([]);
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [algoScore, setAlgoScore] = useState<{ grade: string; totalScore: number; summary: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const platforms = [
    { id: "instagram", label: "اینستاگرام" },
    { id: "twitter", label: "X" },
    { id: "linkedin", label: "لینکدین" },
    { id: "tiktok", label: "تیک‌تاک" },
    { id: "youtube", label: "یوتیوب" },
    { id: "telegram", label: "تلگرام" },
    { id: "eitaa", label: "ایتا" },
    { id: "bale", label: "بله" },
  ];

  useEffect(() => {
    fetch("/api/posts?status=scheduled")
      .then((r) => r.json())
      .then((d) => d.success && setScheduledPosts(d.posts))
      .catch(() => {});
    fetch("/api/automation/enhance")
      .then((r) => r.json())
      .then((d) => d.templates && setTemplates(d.templates))
      .catch(() => {});
  }, []);

  const togglePlatform = (p: string) => {
    setSelectedPlatforms((prev) =>
      prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]
    );
  };

  const applyTemplate = async (templateId: string) => {
    setEnhancing(true);
    try {
      const res = await fetch("/api/automation/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          templateId,
          platforms: selectedPlatforms,
          applyHashtags: true,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setContent(data.caption || "");
        setHashtags(data.hashtags || []);
        setBestTimes(data.bestTimes || []);
        setMessage({ type: "success", text: `قالب «${data.template?.title}» اعمال شد` });
      }
    } catch {
      setMessage({ type: "error", text: "خطا در اعمال قالب" });
    } finally {
      setEnhancing(false);
    }
  };

  const enhanceCurrent = async () => {
    if (!content.trim()) {
      setMessage({ type: "error", text: "اول متن را بنویسید" });
      return;
    }
    setEnhancing(true);
    try {
      const res = await fetch("/api/automation/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caption: content,
          platforms: selectedPlatforms,
          applyHashtags: true,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setContent(data.caption);
        setHashtags(data.hashtags || []);
        setBestTimes(data.bestTimes || []);
        setMessage({ type: "success", text: "هشتگ و زمان پیشنهادی اضافه شد" });
      }
    } catch {
      setMessage({ type: "error", text: "خطا در بهبود کپشن" });
    } finally {
      setEnhancing(false);
    }
  };


  const scoreAlgorithm = async () => {
    if (!content.trim()) {
      setMessage({ type: "error", text: "اول متن را بنویسید" });
      return;
    }
    setEnhancing(true);
    try {
      const res = await fetch("/api/algorithm/score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          caption: content,
          surface: selectedPlatforms.includes("instagram") ? "reels" : "feed",
          hasVideo: uploadedUrls.some((u) => u.match(/\.(mp4|webm)$/i)),
          estimatedDurationSec: 20,
        }),
      });
      const data = await res.json();
      if (data.success && data.report) {
        setAlgoScore({
          grade: data.report.grade,
          totalScore: data.report.totalScore,
          summary: data.report.summary,
        });
        setMessage({
          type: "success",
          text: `امتیاز الگوریتم: ${data.report.grade} (${data.report.totalScore})`,
        });
      }
    } catch {
      setMessage({ type: "error", text: "خطا در امتیاز الگوریتم" });
    } finally {
      setEnhancing(false);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: form });
      const data = await res.json();
      if (data.success) setUploadedUrls((prev) => [...prev, data.media.url]);
      else setMessage({ type: "error", text: data.error || "خطا در آپلود" });
    } catch {
      setMessage({ type: "error", text: "آپلود ناموفق" });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleSubmit = async (immediately = false) => {
    if (!content.trim() || selectedPlatforms.length === 0) {
      setMessage({ type: "error", text: "متن و حداقل یک پلتفرم الزامی است" });
      return;
    }
    setLoading(true);
    setMessage(null);
    try {
      let scheduledAt: string | undefined;
      if (!immediately && scheduledDate && scheduledTime) {
        scheduledAt = new Date(`${scheduledDate}T${scheduledTime}:00`).toISOString();
      }
      const postRes = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content,
          platforms: selectedPlatforms,
          scheduledAt: scheduledAt || null,
          mediaUrls: uploadedUrls,
          status: immediately ? "published" : scheduledAt ? "scheduled" : "draft",
        }),
      });
      const postData = await postRes.json();
      if (!postRes.ok) throw new Error(postData.error || "خطا در ذخیره");

      try {
        await fetch("/api/schedule", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            content,
            platforms: selectedPlatforms,
            scheduledAt,
            publishImmediately: immediately,
            mediaUrls: uploadedUrls,
          }),
        });
      } catch {
        /* Redis optional */
      }

      setMessage({
        type: "success",
        text: immediately
          ? "پست ذخیره و برای انتشار ارسال شد"
          : scheduledAt
          ? "پست زمان‌بندی و ذخیره شد"
          : "پیش‌نویس ذخیره شد",
      });
      setContent("");
      setScheduledDate("");
      setScheduledTime("");
      setUploadedUrls([]);
      setHashtags([]);
      fetch("/api/posts?status=scheduled")
        .then((r) => r.json())
        .then((d) => d.success && setScheduledPosts(d.posts));
    } catch (err: any) {
      setMessage({ type: "error", text: err.message || "خطا – db:setup را چک کنید" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header title="زمان‌بندی هوشمند" />
      <div className="grid grid-cols-1 gap-6 p-8 lg:grid-cols-5">
        <div className="lg:col-span-3 space-y-4">
          {/* Templates */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <LayoutTemplate className="h-5 w-5" />
                نوع پست مفید (قالب آماده)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {templates.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    disabled={enhancing}
                    onClick={() => applyTemplate(t.id)}
                    className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium hover:border-indigo-400 hover:bg-indigo-50 dark:border-gray-700 dark:bg-gray-900"
                    title={t.description}
                  >
                    {t.title}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-gray-400">
                با یک کلیک کپشن + هشتگ مناسب پر می‌شود
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5" />
                ایجاد پست
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div>
                <label className="mb-2 block text-sm font-medium">پلتفرم‌ها</label>
                <div className="flex flex-wrap gap-2">
                  {platforms.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => togglePlatform(p.id)}
                      className={`rounded-lg px-4 py-2 text-sm font-medium transition ${
                        selectedPlatforms.includes(p.id)
                          ? "bg-indigo-600 text-white"
                          : "bg-gray-100 text-gray-600 dark:bg-gray-800"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium">متن پست</label>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="gap-1.5"
                      disabled={enhancing}
                      onClick={enhanceCurrent}
                    >
                      {enhancing ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="h-3.5 w-3.5" />
                      )}
                      هشتگ خودکار
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      disabled={enhancing}
                      onClick={scoreAlgorithm}
                    >
                      امتیاز الگوریتم
                    </Button>
                  </div>
                </div>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={7}
                  placeholder="متن را بنویسید یا از قالب بالا استفاده کنید..."
                  className="w-full rounded-lg border border-gray-200 bg-white p-3 text-sm outline-none focus:border-indigo-500 dark:border-gray-700 dark:bg-gray-900"
                />
                {hashtags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {hashtags.map((h) => (
                      <span
                        key={h}
                        className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
                      >
                        {h}
                      </span>
                    ))}
                  </div>
                )}
                {bestTimes.length > 0 && (
                  <p className="mt-2 text-xs text-emerald-600">
                    ⏰ زمان پیشنهادی: {bestTimes.join(" | ")}
                  </p>
                )}
                {algoScore && (
                  <p className="mt-2 text-xs text-indigo-700">
                    📊 الگوریتم: {algoScore.grade} ({algoScore.totalScore}) — {algoScore.summary}
                  </p>
                )}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">رسانه</label>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*,video/mp4,video/webm"
                  className="hidden"
                  onChange={handleUpload}
                />
                <div
                  onClick={() => fileRef.current?.click()}
                  className="flex h-24 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 dark:border-gray-700 dark:bg-gray-900"
                >
                  {uploading ? (
                    <Loader2 className="h-6 w-6 animate-spin text-indigo-500" />
                  ) : (
                    <div className="text-center text-gray-400 text-sm">
                      <ImageIcon className="mx-auto h-6 w-6" />
                      آپلود عکس / ویدیو
                    </div>
                  )}
                </div>
                {uploadedUrls.length > 0 && (
                  <div className="mt-2 flex gap-2">
                    {uploadedUrls.map((url) => (
                      <div key={url} className="relative">
                        <img src={url} alt="" className="h-14 w-14 rounded object-cover" />
                        <button
                          type="button"
                          onClick={() => setUploadedUrls((p) => p.filter((u) => u !== url))}
                          className="absolute -top-1 -right-1 rounded-full bg-red-500 p-0.5 text-white"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-2 flex items-center gap-1.5 text-sm font-medium">
                    <Calendar className="h-4 w-4" /> تاریخ
                  </label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                  />
                </div>
                <div>
                  <label className="mb-2 flex items-center gap-1.5 text-sm font-medium">
                    <Clock className="h-4 w-4" /> ساعت
                  </label>
                  <input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                  />
                </div>
              </div>

              {message && (
                <div
                  className={`rounded-lg p-3 text-sm ${
                    message.type === "success"
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-red-50 text-red-700"
                  }`}
                >
                  {message.type === "success" && (
                    <CheckCircle className="inline h-4 w-4 ml-1" />
                  )}
                  {message.text}
                </div>
              )}

              <div className="flex gap-3">
                <Button className="flex-1" disabled={loading} onClick={() => handleSubmit(false)}>
                  {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                  زمان‌بندی
                </Button>
                <Button variant="outline" disabled={loading} onClick={() => handleSubmit(false)}>
                  پیش‌نویس
                </Button>
                <Button variant="secondary" disabled={loading} onClick={() => handleSubmit(true)}>
                  انتشار فوری
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">صف انتشار</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {scheduledPosts.length === 0 ? (
                <p className="text-sm text-gray-400">خالی است</p>
              ) : (
                scheduledPosts.map((post) => (
                  <div
                    key={post.id}
                    className="rounded-lg border border-gray-100 bg-gray-50 p-3 dark:border-gray-800 dark:bg-gray-900"
                  >
                    <p className="text-sm line-clamp-2">{post.content}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {(post.platforms || []).map((p) => (
                        <span key={p} className="rounded bg-white px-2 py-0.5 text-xs shadow-sm dark:bg-gray-800">
                          {platformLabel(p)}
                        </span>
                      ))}
                    </div>
                    <p className="mt-1 text-xs text-indigo-600">
                      {post.scheduledAt && formatDate(post.scheduledAt)}
                    </p>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
          <Card className="border-indigo-100 bg-indigo-50/50 dark:border-indigo-900 dark:bg-indigo-950/30">
            <CardContent className="p-4 text-xs text-indigo-800 dark:text-indigo-200">
              <p className="font-medium">اتوماسیون فعال</p>
              <p className="mt-1">
                قالب پست → هشتگ خودکار → زمان پیشنهادی → ذخیره + صف انتشار.
                پاسخ خودکار کامنت را از «تنظیمات» روشن کنید.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
