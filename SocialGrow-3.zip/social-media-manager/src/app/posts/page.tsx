"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { platformLabel, formatDate } from "@/lib/utils";
import { Plus, Filter, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import Link from "next/link";

interface Post {
  id: string;
  content: string;
  status: string;
  platforms: string[];
  scheduledAt: string | null;
  publishedAt: string | null;
  engagement: { likes: number; comments: number; shares: number; views?: number } | null;
  createdAt: string;
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string }> = {
    published: { label: "منتشر شده", className: "bg-emerald-100 text-emerald-700" },
    scheduled: { label: "زمان‌بندی", className: "bg-blue-100 text-blue-700" },
    draft: { label: "پیش‌نویس", className: "bg-gray-100 text-gray-700" },
    failed: { label: "ناموفق", className: "bg-red-100 text-red-700" },
  };
  const item = map[status] || map.draft;
  return (
    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${item.className}`}>
      {item.label}
    </span>
  );
}

export default function PostsPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPosts = async (status?: string) => {
    try {
      setLoading(true);
      const q = status && status !== "all" ? `?status=${status}` : "";
      const res = await fetch(`/api/posts${q}`);
      const data = await res.json();
      if (data.success) {
        setPosts(data.posts);
        setError(null);
      } else {
        setError(data.error);
      }
    } catch {
      setError("اتصال به دیتابیس برقرار نشد. npm run db:setup را اجرا کنید.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts(filter);
  }, [filter]);

  return (
    <>
      <Header title="مدیریت پست‌ها" />
      <div className="space-y-6 p-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            {(["all", "published", "scheduled", "draft"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                  filter === f
                    ? "bg-indigo-100 text-indigo-700"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {f === "all"
                  ? "همه"
                  : f === "published"
                  ? "منتشر شده"
                  : f === "scheduled"
                  ? "زمان‌بندی"
                  : "پیش‌نویس"}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <a href="/api/export/posts" download>
              <Button variant="outline" size="sm" type="button">
                خروجی CSV
              </Button>
            </a>
            <Link href="/scheduler">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                ایجاد پست جدید
              </Button>
            </Link>
          </div>
        </div>

        {loading && (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          </div>
        )}

        {error && (
          <Card className="border-amber-200 bg-amber-50">
            <CardContent className="p-4 text-sm text-amber-800">{error}</CardContent>
          </Card>
        )}

        {!loading && posts.length === 0 && !error && (
          <Card>
            <CardContent className="p-8 text-center text-gray-400">
              پستی یافت نشد.
            </CardContent>
          </Card>
        )}

        <div className="space-y-3">
          {posts.map((post) => (
            <Card key={post.id}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-line">
                      {post.content}
                    </p>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <StatusBadge status={post.status} />
                      {(post.platforms || []).map((p) => (
                        <span
                          key={p}
                          className="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800"
                        >
                          {platformLabel(p)}
                        </span>
                      ))}
                      {post.scheduledAt && (
                        <span className="text-xs text-gray-400">
                          📅 {formatDate(post.scheduledAt)}
                        </span>
                      )}
                      {post.publishedAt && (
                        <span className="text-xs text-gray-400">
                          منتشر شده: {formatDate(post.publishedAt)}
                        </span>
                      )}
                    </div>
                  </div>
                  {post.engagement && (
                    <div className="flex gap-4 text-center text-sm text-gray-500 shrink-0">
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">
                          {post.engagement.likes}
                        </p>
                        <p className="text-xs">لایک</p>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">
                          {post.engagement.comments}
                        </p>
                        <p className="text-xs">کامنت</p>
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">
                          {post.engagement.shares}
                        </p>
                        <p className="text-xs">شیر</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </>
  );
}
