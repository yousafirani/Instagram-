"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Loader2, MessageSquare, Plus, Trash2, Send } from "lucide-react";

interface Rule {
  id?: string;
  keyword: string;
  response: string;
  matchType?: string;
  active?: boolean;
  priority?: number;
  hitCount?: number;
}

export default function DmBotPage() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [keyword, setKeyword] = useState("قیمت");
  const [response, setResponse] = useState("");
  const [matchType, setMatchType] = useState<"contains" | "exact">("contains");
  const [saving, setSaving] = useState(false);
  const [testInput, setTestInput] = useState("قیمت لطفا");
  const [testResult, setTestResult] = useState("");
  const [message, setMessage] = useState("");

  const load = () => {
    setLoading(true);
    fetch("/api/dm-rules")
      .then((r) => r.json())
      .then((d) => {
        if (d.rules) setRules(d.rules);
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!keyword.trim() || !response.trim()) {
      setMessage("کلمه و متن پاسخ لازم است");
      return;
    }
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/dm-rules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyword, response, matchType, active: true, priority: 10 }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage("قانون ذخیره شد");
        setResponse("");
        load();
      } else setMessage(data.error || "خطا");
    } catch {
      setMessage("خطا در ذخیره");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id?: string) => {
    if (!id) return;
    await fetch(`/api/dm-rules?id=${id}`, { method: "DELETE" });
    load();
  };

  const runTest = () => {
    const normalized = testInput.trim().toLowerCase();
    const sorted = [...rules]
      .filter((r) => r.active !== false)
      .sort((a, b) => (b.priority || 0) - (a.priority || 0));
    for (const r of sorted) {
      const kw = r.keyword.toLowerCase();
      const hit =
        r.matchType === "exact" ? normalized === kw : normalized.includes(kw);
      if (hit) {
        setTestResult(r.response);
        return;
      }
    }
    setTestResult("(هیچ قانونی مطابقت نداشت)");
  };

  return (
    <>
      <Header title="ربات دایرکت (کلمه کلیدی)" />
      <div className="space-y-6 p-4 sm:p-8 max-w-3xl">
        <Card className="border-emerald-200 bg-emerald-50/50 dark:border-emerald-900 dark:bg-emerald-950/30">
          <CardContent className="p-4 text-sm text-emerald-900 dark:text-emerald-200">
            <p className="font-medium">چطور کار می‌کند؟</p>
            <p className="mt-1 text-xs">
              وقتی مخاطب در دایرکت اینستاگرام کلمه‌ای مثل «قیمت» بفرستد، همان لحظه
              متن قیمت و شرایط برایش ارسال می‌شود. این فقط پاسخ به پیام ورودی است —
              نه ارسال انبوه به همه فالوورها.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Plus className="h-4 w-4" />
              قانون جدید
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="sm:col-span-1">
                <label className="text-xs font-medium">کلمه کلیدی</label>
                <input
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="mt-1 w-full rounded-lg border px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                  placeholder="قیمت"
                />
              </div>
              <div className="sm:col-span-1">
                <label className="text-xs font-medium">نوع تطبیق</label>
                <select
                  value={matchType}
                  onChange={(e) => setMatchType(e.target.value as "exact" | "contains")}
                  className="mt-1 w-full rounded-lg border px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
                >
                  <option value="contains">شامل کلمه</option>
                  <option value="exact">دقیقاً همان</option>
                </select>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium">متن پاسخ (قیمت و شرایط)</label>
              <textarea
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                rows={6}
                placeholder="سلام، قیمت پلن‌ها به این صورت است..."
                className="mt-1 w-full rounded-lg border px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
              />
            </div>
            <Button onClick={save} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />}
              ذخیره قانون
            </Button>
            {message && <p className="text-sm text-indigo-600">{message}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">قوانین فعال</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading ? (
              <Loader2 className="h-6 w-6 animate-spin text-indigo-600" />
            ) : rules.length === 0 ? (
              <p className="text-sm text-gray-400">قانونی نیست</p>
            ) : (
              rules.map((r) => (
                <div
                  key={r.id || r.keyword}
                  className="rounded-lg border border-gray-100 p-3 dark:border-gray-800"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-medium text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                        {r.keyword}
                      </span>
                      <span className="mr-2 text-xs text-gray-400">
                        {r.matchType === "exact" ? "دقیق" : "شامل"}
                        {r.hitCount != null ? ` · ${r.hitCount} بار` : ""}
                      </span>
                      <p className="mt-2 whitespace-pre-wrap text-sm text-gray-700 dark:text-gray-300">
                        {r.response}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(r.id)}
                      className="text-red-500 hover:bg-red-50 rounded p-1"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Send className="h-4 w-4" />
              تست محلی (بدون اینستاگرام)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <input
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              className="w-full rounded-lg border px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
              placeholder="پیام فرضی مخاطب..."
            />
            <Button variant="outline" onClick={runTest}>
              شبیه‌سازی پاسخ
            </Button>
            {testResult && (
              <pre className="whitespace-pre-wrap rounded-lg bg-gray-50 p-3 text-sm dark:bg-gray-900">
                {testResult}
              </pre>
            )}
          </CardContent>
        </Card>

        <Card className="border-gray-200">
          <CardHeader>
            <CardTitle className="text-base">اتصال Webhook واقعی</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs text-gray-600 dark:text-gray-400">
            <p>۱. برنامه را روی دامنه HTTPS (مثلاً Vercel) منتشر کنید</p>
            <p>
              ۲. در Meta App → Webhooks:{" "}
              <code className="rounded bg-gray-100 px-1 dark:bg-gray-800">
                https://YOUR_DOMAIN/api/instagram/webhook
              </code>
            </p>
            <p>
              ۳. Verify Token = مقدار{" "}
              <code className="rounded bg-gray-100 px-1 dark:bg-gray-800">
                INSTAGRAM_WEBHOOK_VERIFY_TOKEN
              </code>{" "}
              در .env
            </p>
            <p>۴. اشتراک messages را فعال کنید</p>
            <p>
              ۵.{" "}
              <code className="rounded bg-gray-100 px-1 dark:bg-gray-800">
                INSTAGRAM_PAGE_ACCESS_TOKEN
              </code>{" "}
              را تنظیم کنید
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
