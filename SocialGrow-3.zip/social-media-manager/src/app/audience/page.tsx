"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ALL_INTERESTS, getInterestLabel } from "@/lib/audience-targeting";
import { Target, Lightbulb, Hash, Clock, Loader2, Sparkles } from "lucide-react";
import { useState } from "react";

export default function AudiencePage() {
  const [selected, setSelected] = useState<string[]>(["business", "tech"]);
  const [locations, setLocations] = useState("");
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [message, setMessage] = useState("");

  const toggle = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const analyze = async () => {
    if (selected.length === 0) return;
    setLoading(true);
    setMessage("");
    try {
      const res = await fetch("/api/audience", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          interests: selected,
          locations: locations
            ? locations.split(",").map((s) => s.trim()).filter(Boolean)
            : undefined,
          platforms: ["instagram"],
        }),
      });
      const data = await res.json();
      if (data.success) {
        setInsights(data.insights || []);
        setSuggestions(data.suggestions || []);
        setMessage(data.message || "");
      }
    } catch {
      setMessage("خطا در دریافت پیشنهادها");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Header title="هدف‌گذاری مخاطب (محتوا)" />
      <div className="space-y-6 p-8">
        <Card className="border-indigo-200 bg-indigo-50/50 dark:border-indigo-900 dark:bg-indigo-950/30">
          <CardContent className="p-4 text-sm text-indigo-800 dark:text-indigo-200">
            <p className="font-medium flex items-center gap-2">
              <Target className="h-4 w-4" />
              این ابزار برای تولید محتوای بهتر است
            </p>
            <p className="mt-1 text-xs">
              معیارها را انتخاب کنید تا پیشنهاد هشتگ، زمان پست و نوع محتوا بگیرید.
              این سیستم برای فالو اجباری یا اسپم طراحی نشده است.
            </p>
          </CardContent>
        </Card>

        {/* Criteria */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">معیارهای هدف</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium">علایق</label>
              <div className="flex flex-wrap gap-2">
                {ALL_INTERESTS.map((id) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => toggle(id)}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                      selected.includes(id)
                        ? "bg-indigo-600 text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800"
                    }`}
                  >
                    {getInterestLabel(id)}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="mb-2 block text-sm font-medium">
                لوکیشن (اختیاری – با کاما جدا کنید)
              </label>
              <input
                value={locations}
                onChange={(e) => setLocations(e.target.value)}
                placeholder="تهران, اصفهان, ایران"
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500 dark:border-gray-700 dark:bg-gray-900"
              />
            </div>
            <Button onClick={analyze} disabled={loading || selected.length === 0} className="gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              تولید پیشنهاد محتوا
            </Button>
            {message && <p className="text-xs text-gray-500">{message}</p>}
          </CardContent>
        </Card>

        {/* Insights */}
        {insights.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">سگمنت‌های مخاطب</h2>
            <div className="grid gap-4 md:grid-cols-2">
              {insights.map((ins, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">{ins.segmentName}</CardTitle>
                    <p className="text-xs text-gray-500">{ins.sizeEstimate}</p>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div>
                      <p className="font-medium text-gray-700 dark:text-gray-300">محتوای پیشنهادی</p>
                      <ul className="mt-1 space-y-0.5 text-gray-600 dark:text-gray-400">
                        {ins.recommendedContent.map((c: string, j: number) => (
                          <li key={j}>• {c}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-gray-500">
                      <Clock className="h-3.5 w-3.5" />
                      {ins.bestPostingTimes?.join(" | ")}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {ins.suggestedHashtags?.map((h: string) => (
                        <span
                          key={h}
                          className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
                        >
                          {h}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Content suggestions */}
        {suggestions.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Lightbulb className="h-5 w-5" />
              پیشنهادهای محتوا
            </h2>
            <div className="space-y-3">
              {suggestions.map((s, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <h3 className="font-medium text-gray-900 dark:text-white">{s.title}</h3>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">{s.description}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        بهترین زمان: {s.bestTime}
                      </span>
                      <span>{s.platform}</span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {s.hashtags?.map((h: string) => (
                        <span
                          key={h}
                          className="inline-flex items-center gap-0.5 rounded bg-gray-100 px-2 py-0.5 text-xs dark:bg-gray-800"
                        >
                          <Hash className="h-3 w-3" />
                          {h.replace("#", "")}
                        </span>
                      ))}
                    </div>
                    <p className="mt-2 text-xs text-indigo-600">{s.reason}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
