"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { Loader2, Bot, Hash, Clock, MessageCircle } from "lucide-react";

interface AutoSettings {
  autoReplyComments: boolean;
  autoReplyDelayMinutes: number;
  autoReplyOnlyQuestions: boolean;
  autoHashtags: boolean;
  autoBestTime: boolean;
  maxAutoRepliesPerHour: number;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<AutoSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [running, setRunning] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/automation/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d.settings) setSettings(d.settings);
      })
      .finally(() => setLoading(false));
  }, []);

  const save = async () => {
    if (!settings) return;
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/automation/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      setMessage(data.message || "ذخیره شد");
    } catch {
      setMessage("خطا در ذخیره");
    } finally {
      setSaving(false);
    }
  };

  const runAutoReply = async () => {
    setRunning(true);
    setMessage("");
    try {
      const res = await fetch("/api/automation/auto-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 5 }),
      });
      const data = await res.json();
      setMessage(data.message || data.error || "انجام شد");
    } catch {
      setMessage("خطا – دیتابیس راه‌اندازی شده؟");
    } finally {
      setRunning(false);
    }
  };

  if (loading || !settings) {
    return (
      <>
        <Header title="تنظیمات" />
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
        </div>
      </>
    );
  }

  return (
    <>
      <Header title="تنظیمات و اتوماسیون" />
      <div className="mx-auto max-w-3xl space-y-6 p-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Bot className="h-5 w-5" />
              اتوماسیون مجاز
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5 text-sm">
            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={settings.autoReplyComments}
                onChange={(e) =>
                  setSettings({ ...settings, autoReplyComments: e.target.checked })
                }
                className="mt-1 h-4 w-4 rounded"
              />
              <div>
                <span className="font-medium flex items-center gap-1.5">
                  <MessageCircle className="h-4 w-4" />
                  پاسخ خودکار به کامنت‌های پست خودم
                </span>
                <p className="text-xs text-gray-500 mt-0.5">
                  فقط زیر پست‌های شما – با AI. پیش‌فرض خاموش است.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={settings.autoReplyOnlyQuestions}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    autoReplyOnlyQuestions: e.target.checked,
                  })
                }
                className="mt-1 h-4 w-4 rounded"
              />
              <div>
                <span className="font-medium">فقط به سؤال‌ها پاسخ بده</span>
                <p className="text-xs text-gray-500 mt-0.5">
                  کامنت‌هایی که علامت سؤال یا کلمات پرسشی دارند
                </p>
              </div>
            </label>

            <div>
              <label className="block font-medium mb-1">
                تأخیر پاسخ خودکار (دقیقه)
              </label>
              <input
                type="number"
                min={1}
                max={120}
                value={settings.autoReplyDelayMinutes}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    autoReplyDelayMinutes: Number(e.target.value) || 15,
                  })
                }
                className="w-32 rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
              />
              <p className="text-xs text-gray-500 mt-1">
                برای طبیعی‌تر بودن – پیشنهاد: ۱۵ تا ۳۰ دقیقه
              </p>
            </div>

            <div>
              <label className="block font-medium mb-1">
                حداکثر پاسخ خودکار در ساعت
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={settings.maxAutoRepliesPerHour}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    maxAutoRepliesPerHour: Number(e.target.value) || 10,
                  })
                }
                className="w-32 rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
              />
            </div>

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={settings.autoHashtags}
                onChange={(e) =>
                  setSettings({ ...settings, autoHashtags: e.target.checked })
                }
                className="mt-1 h-4 w-4 rounded"
              />
              <div>
                <span className="font-medium flex items-center gap-1.5">
                  <Hash className="h-4 w-4" />
                  هشتگ خودکار روی کپشن
                </span>
                <p className="text-xs text-gray-500 mt-0.5">
                  هنگام زمان‌بندی یا انتخاب قالب پست
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={settings.autoBestTime}
                onChange={(e) =>
                  setSettings({ ...settings, autoBestTime: e.target.checked })
                }
                className="mt-1 h-4 w-4 rounded"
              />
              <div>
                <span className="font-medium flex items-center gap-1.5">
                  <Clock className="h-4 w-4" />
                  پیشنهاد بهترین زمان انتشار
                </span>
              </div>
            </label>

            <div className="flex flex-wrap gap-2 pt-2">
              <Button onClick={save} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                ذخیره تنظیمات
              </Button>
              <Button
                variant="secondary"
                onClick={runAutoReply}
                disabled={running || !settings.autoReplyComments}
              >
                {running ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                الان پاسخ خودکار را اجرا کن
              </Button>
            </div>
            {message && (
              <p className="text-sm text-indigo-700 dark:text-indigo-300">{message}</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">تنظیمات عمومی</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium">نام برند</label>
              <input
                defaultValue="SocialGrow"
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">منطقه زمانی</label>
              <select className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900">
                <option>Asia/Tehran (IRST)</option>
                <option>UTC</option>
              </select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/40">
          <CardContent className="p-4 text-sm text-amber-900 dark:text-amber-200">
            <p className="font-medium">محدوده اتوماسیون</p>
            <p className="mt-1 text-xs">
              پاسخ خودکار فقط برای کامنت‌های زیر پست‌های خودتان است. فالو خودکار،
              لایک انبوه و دایرکت اسپم پشتیبانی نمی‌شود چون خلاف قوانین پلتفرم‌هاست.
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
