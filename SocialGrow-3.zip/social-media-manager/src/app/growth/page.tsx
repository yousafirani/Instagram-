"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  GROWTH_PILLARS,
  WEEKLY_PLAN,
  QUICK_WINS,
  getImpactLabel,
} from "@/lib/growth";
import {
  TrendingUp,
  CheckCircle2,
  Calendar,
  Zap,
  ArrowLeft,
  Shield,
  Target,
  MessageCircle,
  FileText,
  User,
  BarChart3,
} from "lucide-react";
import Link from "next/link";
import { useState } from "react";

const typeColor: Record<string, string> = {
  content: "bg-indigo-100 text-indigo-700",
  engage: "bg-emerald-100 text-emerald-700",
  analyze: "bg-amber-100 text-amber-700",
  optimize: "bg-purple-100 text-purple-700",
};

const typeLabel: Record<string, string> = {
  content: "محتوا",
  engage: "تعامل",
  analyze: "تحلیل",
  optimize: "بهینه‌سازی",
};

const FIVE_ACTIONS = [
  {
    id: "bio",
    title: "۱. بایو شفاف با CTA",
    desc: "نام کاربری + یک خط ارزش + فراخوان به اقدام (لینک یا کلمه کلیدی).",
    href: "/accounts",
    icon: User,
    tip: "مثال: «کمک به رشد کسب‌وکارهای آنلاین | لینک دوره رایگان در استوری»",
  },
  {
    id: "schedule",
    title: "۲. زمان‌بندی ۳ پست بعدی",
    desc: "ثبات انتشار مهم‌تر از کمال است. همین الان ۳ پست را زمان‌بندی کنید.",
    href: "/scheduler",
    icon: Calendar,
    tip: "ترکیب: آموزشی + پشت‌صحنه + تعاملی",
  },
  {
    id: "comments",
    title: "۳. پاسخ به کامنت‌های اخیر",
    desc: "با کمک پیشنهاد AI سریع و انسانی جواب دهید (نیم ساعت اول طلایی است).",
    href: "/comments",
    icon: MessageCircle,
    tip: "پاسخ کامل > ایموجی تنها",
  },
  {
    id: "audience",
    title: "۴. هدف‌گذاری محتوا و هشتگ",
    desc: "معیار علایق را انتخاب کنید و هشتگ + بهترین زمان را بگیرید.",
    href: "/audience",
    icon: Target,
    tip: "هشتگ بزرگ + متوسط + نیش را ترکیب کنید",
  },
  {
    id: "review",
    title: "۵. بررسی هفتگی آنالیتیکس",
    desc: "فرمت‌های پربازده را تکرار کنید و فالوور مشکوک را چک کنید.",
    href: "/analytics",
    icon: BarChart3,
    tip: "هر پنجشنبه ۱۵ دقیقه کافی است",
  },
];

export default function GrowthPage() {
  const [done, setDone] = useState<Record<string, boolean>>({});

  const toggle = (id: string) => {
    setDone((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = Object.values(done).filter(Boolean).length;

  return (
    <>
      <Header title="رشد ارگانیک فالوور" />
      <div className="space-y-8 p-8">
        <Card className="border-indigo-200 bg-gradient-to-l from-indigo-50 to-white dark:from-indigo-950/40 dark:to-gray-950">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-600 text-white">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  کار درست برای افزایش فالوور
                </h2>
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 max-w-2xl">
                  پنج اقدام عملی زیر را انجام دهید. هر کدام به ابزار داخل همین
                  برنامه وصل است. یوتیوب هم به پلتفرم‌های پشتیبانی‌شده اضافه شده.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 5 Actions Checklist */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-lg font-semibold">
              <Zap className="h-5 w-5 text-amber-500" />
              ۵ اقدام عملی همین هفته
            </h3>
            <span className="text-sm text-gray-500">
              {completedCount} از ۵ انجام شد
            </span>
          </div>
          <div className="space-y-3">
            {FIVE_ACTIONS.map((action) => {
              const Icon = action.icon;
              const isDone = done[action.id];
              return (
                <Card
                  key={action.id}
                  className={isDone ? "border-emerald-200 bg-emerald-50/40 dark:bg-emerald-950/20" : ""}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <button
                        type="button"
                        onClick={() => toggle(action.id)}
                        className={`mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition ${
                          isDone
                            ? "border-emerald-500 bg-emerald-500 text-white"
                            : "border-gray-300 hover:border-indigo-400"
                        }`}
                      >
                        {isDone && <CheckCircle2 className="h-4 w-4" />}
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <Icon className="h-4 w-4 text-indigo-600" />
                          <h4 className="font-medium text-gray-900 dark:text-white">
                            {action.title}
                          </h4>
                        </div>
                        <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                          {action.desc}
                        </p>
                        <p className="mt-1 text-xs text-indigo-600 dark:text-indigo-400">
                          💡 {action.tip}
                        </p>
                      </div>
                      <Link href={action.href}>
                        <button className="flex items-center gap-1 rounded-lg bg-indigo-50 px-3 py-1.5 text-xs font-medium text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-300">
                          برو
                          <ArrowLeft className="h-3.5 w-3.5" />
                        </button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Quick wins */}
        <div>
          <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold">
            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            کارهای سریع بیشتر
          </h3>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {QUICK_WINS.map((item, i) => (
              <Card key={i}>
                <CardContent className="flex items-start gap-3 p-4">
                  <span className="mt-0.5 text-emerald-500">✓</span>
                  <p className="text-sm text-gray-700 dark:text-gray-300">{item}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Pillars */}
        <div>
          <h3 className="mb-3 text-lg font-semibold">۶ ستون رشد پایدار</h3>
          <div className="grid gap-4 lg:grid-cols-2">
            {GROWTH_PILLARS.map((pillar) => (
              <Card key={pillar.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{pillar.title}</CardTitle>
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
                        pillar.impact === "high"
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {getImpactLabel(pillar.impact)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500">{pillar.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1.5">
                    {pillar.actions.map((a, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2 text-sm text-gray-700 dark:text-gray-300"
                      >
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />
                        {a}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Weekly plan */}
        <div>
          <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold">
            <Calendar className="h-5 w-5" />
            برنامه هفتگی پیشنهادی
          </h3>
          <Card>
            <CardContent className="p-0">
              <div className="divide-y dark:divide-gray-800">
                {WEEKLY_PLAN.map((item) => (
                  <div key={item.day} className="flex items-center gap-4 px-5 py-3">
                    <span className="w-16 shrink-0 text-sm font-medium">
                      {item.day}
                    </span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        typeColor[item.type]
                      }`}
                    >
                      {typeLabel[item.type]}
                    </span>
                    <span className="text-sm text-gray-600 dark:text-gray-300">
                      {item.task}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Platforms including YouTube */}
        <Card className="border-red-100 bg-red-50/30 dark:border-red-900 dark:bg-red-950/20">
          <CardContent className="p-4 text-sm">
            <p className="font-medium text-red-800 dark:text-red-200">
              یوتیوب اضافه شد
            </p>
            <p className="mt-1 text-xs text-red-700 dark:text-red-300">
              حالا می‌توانید اکانت یوتیوب را در بخش اکانت‌ها ببینید، پست/ویدیو را
              برای یوتیوب زمان‌بندی کنید و از اسکلت YouTube Data API
              (src/lib/youtube.ts) برای اتصال واقعی استفاده کنید.
            </p>
          </CardContent>
        </Card>

        {/* What NOT to do */}
        <Card className="border-red-200 bg-red-50/50 dark:border-red-900 dark:bg-red-950/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-base text-red-700 dark:text-red-300">
              کارهایی که انجام ندهید
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-red-800 dark:text-red-200">
            <ul className="space-y-1">
              <li>• خرید فالوور یا لایک</li>
              <li>• فالو و آنفالو انبوه</li>
              <li>• دایرکت و کامنت اسپم</li>
              <li>• نرم‌افزارهای غیررسمی که پسورد اکانت می‌گیرند</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
