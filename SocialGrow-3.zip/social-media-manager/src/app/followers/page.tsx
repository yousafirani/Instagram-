"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, AlertTriangle, Shield, RefreshCw, Info } from "lucide-react";
import { useState, useEffect } from "react";

interface Suspicion {
  score: number;
  reasons: string[];
  level: "low" | "medium" | "high" | "critical";
}

interface Result {
  profile: {
    id: string;
    username: string;
    displayName?: string;
    avatarUrl?: string;
    followersCount: number;
    followingCount: number;
    postsCount: number;
    hasProfilePic: boolean;
    engagementRate?: number;
  };
  suspicion: Suspicion;
}

const levelColor = {
  low: "bg-emerald-100 text-emerald-700",
  medium: "bg-amber-100 text-amber-700",
  high: "bg-orange-100 text-orange-700",
  critical: "bg-red-100 text-red-700",
};

const levelLabel = {
  low: "کم",
  medium: "متوسط",
  high: "بالا",
  critical: "بحرانی",
};

export default function FollowersPage() {
  const [results, setResults] = useState<Result[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/followers/analyze");
      const data = await res.json();
      if (data.success) {
        setResults(data.results);
        setSummary(data.summary);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered =
    filter === "all"
      ? results
      : results.filter((r) => r.suspicion.level === filter);

  return (
    <>
      <Header title="تشخیص فالوور مشکوک" />
      <div className="space-y-6 p-8">
        {/* Disclaimer */}
        <Card className="border-blue-200 bg-blue-50 dark:border-blue-900 dark:bg-blue-950/40">
          <CardContent className="flex items-start gap-3 p-4 text-sm text-blue-800 dark:text-blue-200">
            <Info className="h-5 w-5 shrink-0 mt-0.5" />
            <div>
              <p className="font-medium">فقط گزارش تحلیلی</p>
              <p className="mt-1 text-xs">
                این ابزار هیچ فالووری را به‌صورت خودکار حذف یا بلاک نمی‌کند.
                گزارش را ببینید و خودتان تصمیم بگیرید. حذف خودکار خلاف قوانین
                پلتفرم‌هاست و خطر بن شدن دارد.
              </p>
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          </div>
        ) : (
          <>
            {/* Summary */}
            {summary && (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold">{summary.total}</p>
                    <p className="text-xs text-gray-500">کل بررسی‌شده</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-red-600">{summary.critical}</p>
                    <p className="text-xs text-gray-500">بحرانی</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-orange-600">{summary.high}</p>
                    <p className="text-xs text-gray-500">بالا</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-amber-600">{summary.medium}</p>
                    <p className="text-xs text-gray-500">متوسط</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-2xl font-bold text-emerald-600">{summary.low}</p>
                    <p className="text-xs text-gray-500">کم‌ریسک</p>
                  </CardContent>
                </Card>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex gap-2">
                {(["all", "critical", "high", "medium", "low"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                      filter === f
                        ? "bg-indigo-100 text-indigo-700"
                        : "text-gray-500 hover:bg-gray-100"
                    }`}
                  >
                    {f === "all" ? "همه" : levelLabel[f]}
                  </button>
                ))}
              </div>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={load}>
                <RefreshCw className="h-4 w-4" />
                بروزرسانی
              </Button>
            </div>

            <div className="space-y-3">
              {filtered.map((item) => (
                <Card key={item.profile.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="relative">
                        {item.profile.avatarUrl ? (
                          <img
                            src={item.profile.avatarUrl}
                            alt=""
                            className="h-12 w-12 rounded-full"
                          />
                        ) : (
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gray-200 text-gray-400">
                            ?
                          </div>
                        )}
                        {item.suspicion.level === "critical" ||
                        item.suspicion.level === "high" ? (
                          <AlertTriangle className="absolute -bottom-1 -right-1 h-4 w-4 text-red-500" />
                        ) : null}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium">@{item.profile.username}</span>
                          <span
                            className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                              levelColor[item.suspicion.level]
                            }`}
                          >
                            {levelLabel[item.suspicion.level]} ({item.suspicion.score})
                          </span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-3 text-xs text-gray-500">
                          <span>{item.profile.followersCount} فالوور</span>
                          <span>{item.profile.followingCount} فالوینگ</span>
                          <span>{item.profile.postsCount} پست</span>
                          {item.profile.engagementRate !== undefined && (
                            <span>تعامل: {item.profile.engagementRate.toFixed(1)}%</span>
                          )}
                        </div>
                        {item.suspicion.reasons.length > 0 && (
                          <ul className="mt-2 space-y-0.5">
                            {item.suspicion.reasons.map((r, i) => (
                              <li key={i} className="text-xs text-gray-600 dark:text-gray-400">
                                • {r}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                      <div className="text-left">
                        <Shield className="h-5 w-5 text-gray-300" />
                        <p className="mt-1 text-[10px] text-gray-400">تصمیم با شما</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
}
