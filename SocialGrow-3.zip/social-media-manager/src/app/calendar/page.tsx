"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { platformLabel, formatDate } from "@/lib/utils";
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Loader2, Plus } from "lucide-react";
import Link from "next/link";

interface CalPost {
  id: string;
  content: string;
  status: string;
  platforms: string[];
  scheduledAt: string | null;
  publishedAt: string | null;
}

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function daysInMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
}

export default function CalendarPage() {
  const [cursor, setCursor] = useState(() => startOfMonth(new Date()));
  const [posts, setPosts] = useState<CalPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch("/api/posts")
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setPosts(d.posts || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const totalDays = daysInMonth(cursor);
  const firstWeekday = (startOfMonth(cursor).getDay() + 1) % 7; // adjust for Sat-start feel optional

  const byDay = useMemo(() => {
    const map: Record<string, CalPost[]> = {};
    for (const p of posts) {
      const raw = p.scheduledAt || p.publishedAt;
      if (!raw) continue;
      const dt = new Date(raw);
      if (dt.getFullYear() !== year || dt.getMonth() !== month) continue;
      const key = String(dt.getDate());
      if (!map[key]) map[key] = [];
      map[key].push(p);
    }
    return map;
  }, [posts, year, month]);

  const monthLabel = new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "long",
  }).format(cursor);

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) cells.push(d);

  const statusDot: Record<string, string> = {
    scheduled: "bg-blue-500",
    published: "bg-emerald-500",
    draft: "bg-gray-400",
    failed: "bg-red-500",
  };

  return (
    <>
      <Header title="تقویم محتوا" />
      <div className="space-y-6 p-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                setCursor(new Date(year, month - 1, 1))
              }
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            <h2 className="min-w-[140px] text-center text-lg font-semibold">
              {monthLabel}
            </h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                setCursor(new Date(year, month + 1, 1))
              }
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </div>
          <Link href="/scheduler">
            <Button size="sm" className="gap-1.5">
              <Plus className="h-4 w-4" />
              پست جدید
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          </div>
        ) : (
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-gray-500 mb-2">
                {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d) => (
                  <div key={d} className="py-1">
                    {d}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {cells.map((day, i) => (
                  <div
                    key={i}
                    className={`min-h-[88px] rounded-lg border p-1.5 text-right ${
                      day
                        ? "border-gray-100 bg-white dark:border-gray-800 dark:bg-gray-950"
                        : "border-transparent bg-transparent"
                    }`}
                  >
                    {day && (
                      <>
                        <span className="text-xs font-medium text-gray-600">
                          {day}
                        </span>
                        <div className="mt-1 space-y-1">
                          {(byDay[String(day)] || []).slice(0, 3).map((p) => (
                            <div
                              key={p.id}
                              className="truncate rounded px-1 py-0.5 text-[10px] bg-indigo-50 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-200"
                              title={p.content}
                            >
                              <span
                                className={`inline-block h-1.5 w-1.5 rounded-full ml-1 ${
                                  statusDot[p.status] || "bg-gray-400"
                                }`}
                              />
                              {p.content.slice(0, 28)}
                            </div>
                          ))}
                          {(byDay[String(day)] || []).length > 3 && (
                            <span className="text-[10px] text-gray-400">
                              +{(byDay[String(day)] || []).length - 3}
                            </span>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-base">لیست زمان‌بندی این ماه</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {posts
              .filter((p) => {
                const raw = p.scheduledAt || p.publishedAt;
                if (!raw) return false;
                const dt = new Date(raw);
                return dt.getFullYear() === year && dt.getMonth() === month;
              })
              .map((p) => (
                <div
                  key={p.id}
                  className="flex flex-wrap items-center gap-2 rounded-lg border border-gray-100 p-3 text-sm dark:border-gray-800"
                >
                  <span className="text-xs text-gray-400">
                    {p.scheduledAt
                      ? formatDate(p.scheduledAt)
                      : p.publishedAt
                      ? formatDate(p.publishedAt)
                      : "—"}
                  </span>
                  <span className="flex-1 line-clamp-1">{p.content}</span>
                  {(p.platforms || []).map((pl) => (
                    <span
                      key={pl}
                      className="rounded bg-gray-100 px-2 py-0.5 text-xs dark:bg-gray-800"
                    >
                      {platformLabel(pl)}
                    </span>
                  ))}
                </div>
              ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
