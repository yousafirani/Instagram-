"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import StatsCards from "@/components/dashboard/StatsCards";
import PlatformOverview from "@/components/dashboard/PlatformOverview";
import { formatNumber, platformLabel } from "@/lib/utils";
import { Loader2, TrendingUp } from "lucide-react";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function AnalyticsPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <>
        <Header title="آنالیتیکس" />
        <div className="flex justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
        </div>
      </>
    );
  }

  const analytics = data?.analytics;
  const platformStats = data?.platformStats || [];

  return (
    <>
      <Header title="آنالیتیکس" />
      <div className="space-y-6 p-4 sm:p-8">
        {analytics && <StatsCards data={analytics} />}
        <PlatformOverview stats={platformStats} />

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">عملکرد پلتفرم‌ها</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {platformStats.map((s: any) => (
                <div
                  key={s.platform}
                  className="flex items-center justify-between rounded-lg border border-gray-100 p-3 dark:border-gray-800"
                >
                  <div>
                    <p className="font-medium text-sm">{platformLabel(s.platform)}</p>
                    <p className="text-xs text-gray-500">
                      {formatNumber(s.followers)} فالوور · {s.posts} پست
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-semibold text-emerald-600">
                      +{Number(s.growth).toFixed(1)}%
                    </p>
                    <p className="text-xs text-gray-400">
                      تعامل {Number(s.engagementRate).toFixed(1)}%
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="h-4 w-4" />
                پیشنهاد رشد
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
              <p>• ریلز کوتاه با قلاب ۳ ثانیه‌ای منتشر کنید</p>
              <p>• در ساعت اول به کامنت‌ها پاسخ دهید</p>
              <p>• از قالب‌های آموزشی برای افزایش ذخیره استفاده کنید</p>
              <p>• امتیاز الگوریتم را قبل از انتشار چک کنید</p>
              <Link href="/algorithm" className="block pt-2 text-indigo-600 hover:underline">
                رفتن به صفحه الگوریتم ←
              </Link>
              <Link href="/growth" className="block text-indigo-600 hover:underline">
                چک‌لیست رشد فالوور ←
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
