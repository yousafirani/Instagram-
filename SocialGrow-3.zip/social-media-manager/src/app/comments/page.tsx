"use client";

import Header from "@/components/layout/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { platformLabel, formatDate } from "@/lib/utils";
import { Reply, Check, Sparkles, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";

interface Comment {
  id: string;
  platform: string;
  author: string;
  authorAvatar: string | null;
  content: string;
  replied: boolean;
  replyContent: string | null;
  createdAt: string;
}

export default function CommentsPage() {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [loadingAI, setLoadingAI] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [autoReplyRunning, setAutoReplyRunning] = useState(false);
  const [autoMsg, setAutoMsg] = useState("");

  const fetchComments = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/comments");
      const data = await res.json();
      if (data.success) {
        setComments(data.comments);
        setError(null);
      } else {
        setError(data.error);
      }
    } catch {
      setError("اتصال به دیتابیس برقرار نشد. npm run db:setup را اجرا کنید.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  const handleReply = async (id: string) => {
    if (!replyText.trim()) return;
    try {
      const res = await fetch("/api/comments", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ commentId: id, replyContent: replyText }),
      });
      const data = await res.json();
      if (data.success) {
        setComments((prev) =>
          prev.map((c) =>
            c.id === id
              ? { ...c, replied: true, replyContent: replyText }
              : c
          )
        );
        setReplyingTo(null);
        setReplyText("");
      }
    } catch {
      // fallback local
      setComments((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, replied: true, replyContent: replyText } : c
        )
      );
      setReplyingTo(null);
      setReplyText("");
    }
  };

  const handleSuggestAI = async (commentId: string, commentText: string, platform: string) => {
    setLoadingAI(commentId);
    setReplyingTo(commentId);
    try {
      const res = await fetch("/api/comments/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          comment: commentText,
          platform,
          language: "fa",
          brandTone: "friendly",
        }),
      });
      const data = await res.json();
      if (data.suggestion) setReplyText(data.suggestion);
    } catch {
      setReplyText("ممنون از نظرتون! 💙");
    } finally {
      setLoadingAI(null);
    }
  };

  const pending = comments.filter((c) => !c.replied);
  const replied = comments.filter((c) => c.replied);


  const runAutoReply = async () => {
    setAutoReplyRunning(true);
    setAutoMsg("");
    try {
      const res = await fetch("/api/automation/auto-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ limit: 5 }),
      });
      const data = await res.json();
      setAutoMsg(data.message || data.error || "");
      if (data.processed > 0) fetchComments();
    } catch {
      setAutoMsg("خطا – تنظیمات اتوماسیون یا دیتابیس را چک کنید");
    } finally {
      setAutoReplyRunning(false);
    }
  };

  return (
    <>
      <Header title="مدیریت کامنت‌ها" />
      <div className="space-y-6 p-8">
        {loading && (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
          </div>
        )}

        {error && (
          <Card className="border-amber-200 bg-amber-50">
            <CardContent className="p-4 text-sm text-amber-800">{error}</CardContent>
          </Card>
        )}

        {!loading && (
          <>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <span className="rounded-full bg-red-100 px-3 py-1 font-medium text-red-700">
                {pending.length} بدون پاسخ
              </span>
              <span className="rounded-full bg-emerald-100 px-3 py-1 font-medium text-emerald-700">
                {replied.length} پاسخ داده شده
              </span>
              <Button
                size="sm"
                variant="secondary"
                className="gap-1.5"
                disabled={autoReplyRunning}
                onClick={runAutoReply}
              >
                {autoReplyRunning ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Sparkles className="h-3.5 w-3.5" />
                )}
                پاسخ خودکار AI به بدون‌پاسخ‌ها
              </Button>
              {autoMsg && <span className="text-xs text-indigo-600">{autoMsg}</span>}
            </div>

            <div className="space-y-3">
              <h2 className="text-base font-semibold text-gray-800 dark:text-white">
                نیاز به پاسخ
              </h2>
              {pending.length === 0 && (
                <Card>
                  <CardContent className="p-8 text-center text-gray-400">
                    <Check className="mx-auto h-10 w-10 text-emerald-400" />
                    <p className="mt-2">همه کامنت‌ها پاسخ داده شده‌اند!</p>
                  </CardContent>
                </Card>
              )}
              {pending.map((comment) => (
                <Card key={comment.id}>
                  <CardContent className="p-5">
                    <div className="flex items-start gap-3">
                      <img
                        src={
                          comment.authorAvatar ||
                          `https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.author}`
                        }
                        alt={comment.author}
                        className="h-10 w-10 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-gray-900 dark:text-white">
                            {comment.author}
                          </span>
                          <span className="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-500 dark:bg-gray-800">
                            {platformLabel(comment.platform)}
                          </span>
                          <span className="text-xs text-gray-400">
                            {formatDate(comment.createdAt)}
                          </span>
                        </div>
                        <p className="mt-1.5 text-sm text-gray-700 dark:text-gray-300">
                          {comment.content}
                        </p>

                        {replyingTo === comment.id ? (
                          <div className="mt-3 space-y-2">
                            <textarea
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              rows={3}
                              placeholder="پاسخ خود را بنویسید یا از پیشنهاد AI استفاده کنید..."
                              className="w-full rounded-lg border border-gray-200 p-2 text-sm outline-none focus:border-indigo-500 dark:border-gray-700 dark:bg-gray-900"
                              autoFocus
                            />
                            <div className="flex flex-wrap gap-2">
                              <Button size="sm" onClick={() => handleReply(comment.id)}>
                                ارسال پاسخ
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="gap-1.5"
                                disabled={loadingAI === comment.id}
                                onClick={() =>
                                  handleSuggestAI(
                                    comment.id,
                                    comment.content,
                                    comment.platform
                                  )
                                }
                              >
                                {loadingAI === comment.id ? (
                                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : (
                                  <Sparkles className="h-3.5 w-3.5" />
                                )}
                                پیشنهاد AI
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setReplyingTo(null);
                                  setReplyText("");
                                }}
                              >
                                لغو
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="mt-3 flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="gap-1.5"
                              onClick={() => setReplyingTo(comment.id)}
                            >
                              <Reply className="h-3.5 w-3.5" />
                              پاسخ
                            </Button>
                            <Button
                              size="sm"
                              variant="secondary"
                              className="gap-1.5"
                              disabled={loadingAI === comment.id}
                              onClick={() =>
                                handleSuggestAI(
                                  comment.id,
                                  comment.content,
                                  comment.platform
                                )
                              }
                            >
                              {loadingAI === comment.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Sparkles className="h-3.5 w-3.5" />
                              )}
                              پیشنهاد AI
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {replied.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-base font-semibold text-gray-800 dark:text-white">
                  پاسخ داده شده
                </h2>
                {replied.map((comment) => (
                  <Card key={comment.id} className="opacity-80">
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <img
                          src={
                            comment.authorAvatar ||
                            `https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.author}`
                          }
                          alt={comment.author}
                          className="h-10 w-10 rounded-full"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{comment.author}</span>
                            <span className="text-xs text-gray-400">
                              {platformLabel(comment.platform)}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-gray-600">{comment.content}</p>
                          <div className="mt-2 rounded-lg bg-indigo-50 p-3 dark:bg-indigo-950">
                            <p className="text-xs font-medium text-indigo-600 dark:text-indigo-300">
                              پاسخ شما:
                            </p>
                            <p className="mt-0.5 text-sm text-gray-700 dark:text-gray-200">
                              {comment.replyContent}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}
