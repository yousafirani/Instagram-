"use client";

import { Bell, Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Header({ title }: { title: string }) {
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-gray-200 bg-white/90 px-4 backdrop-blur-md dark:border-gray-800 dark:bg-gray-950/90 sm:h-16 sm:px-8">
      <h1 className="truncate text-lg font-bold text-gray-900 dark:text-white sm:text-xl">
        {title}
      </h1>

      <div className="flex items-center gap-2 sm:gap-3">
        <div className="relative hidden md:block">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="جستجو..."
            className="h-9 w-64 rounded-lg border border-gray-200 bg-gray-50 pr-10 pl-4 text-sm outline-none focus:border-indigo-500 dark:border-gray-700 dark:bg-gray-900"
          />
        </div>

        <button
          type="button"
          className="relative rounded-lg p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"
          aria-label="اعلان‌ها"
        >
          <Bell className="h-5 w-5" />
          <span className="absolute left-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500" />
        </button>

        <Link href="/scheduler">
          <Button size="sm" className="gap-1.5">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">پست جدید</span>
          </Button>
        </Link>
      </div>
    </header>
  );
}
