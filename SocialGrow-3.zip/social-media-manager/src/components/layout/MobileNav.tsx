"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Calendar,
  MessageCircle,
  TrendingUp,
  Menu,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import Sidebar from "./Sidebar";

const tabs = [
  { href: "/", label: "خانه", icon: LayoutDashboard },
  { href: "/scheduler", label: "پست", icon: Calendar },
  { href: "/comments", label: "کامنت", icon: MessageCircle },
  { href: "/growth", label: "رشد", icon: TrendingUp },
];

export default function MobileNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Drawer overlay */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setOpen(false)}
          />
          <div className="absolute right-0 top-0 h-full w-72 bg-white shadow-xl dark:bg-gray-950">
            <div className="flex items-center justify-between border-b px-4 py-3">
              <span className="font-bold">منو</span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-1 text-sm text-gray-500"
              >
                بستن
              </button>
            </div>
            <div className="h-[calc(100%-52px)] overflow-y-auto" onClick={() => setOpen(false)}>
              <Sidebar mobile />
            </div>
          </div>
        </div>
      )}

      {/* Bottom tab bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-gray-200 bg-white/95 backdrop-blur dark:border-gray-800 dark:bg-gray-950/95 lg:hidden">
        <div className="flex items-center justify-around px-1 pb-[env(safe-area-inset-bottom)] pt-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = pathname === t.href;
            return (
              <Link
                key={t.href}
                href={t.href}
                className={cn(
                  "flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium",
                  active ? "text-indigo-600" : "text-gray-500"
                )}
              >
                <Icon className="h-5 w-5" />
                {t.label}
              </Link>
            );
          })}
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-medium text-gray-500"
          >
            <Menu className="h-5 w-5" />
            بیشتر
          </button>
        </div>
      </nav>
    </>
  );
}
