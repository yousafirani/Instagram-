"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  FileText,
  Calendar,
  MessageCircle,
  Bot,
  BarChart3,
  Settings,
  Sparkles,
  ShieldAlert,
  Target,
  TrendingUp,
  Gauge,
  CalendarDays,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "داشبورد", icon: LayoutDashboard },
  { href: "/growth", label: "رشد فالوور", icon: TrendingUp },
  { href: "/algorithm", label: "الگوریتم اینستا", icon: Gauge },
  { href: "/calendar", label: "تقویم محتوا", icon: CalendarDays },
  { href: "/accounts", label: "اکانت‌ها", icon: Users },
  { href: "/posts", label: "پست‌ها", icon: FileText },
  { href: "/scheduler", label: "زمان‌بندی", icon: Calendar },
  { href: "/comments", label: "کامنت‌ها", icon: MessageCircle },
  { href: "/dm-bot", label: "ربات دایرکت", icon: Bot },
  { href: "/followers", label: "فالوور مشکوک", icon: ShieldAlert },
  { href: "/audience", label: "هدف‌گذاری محتوا", icon: Target },
  { href: "/analytics", label: "آنالیتیکس", icon: BarChart3 },
  { href: "/settings", label: "تنظیمات", icon: Settings },
];

export default function Sidebar({ mobile = false }: { mobile?: boolean }) {
  const pathname = usePathname();

  const content = (
    <div className="flex h-full flex-col">
      {!mobile && (
        <div className="flex items-center gap-2 border-b border-gray-200 px-6 py-5 dark:border-gray-800">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold text-gray-900 dark:text-white">
              SocialGrow
            </h1>
            <p className="text-xs text-gray-500">مدیریت شبکه‌های اجتماعی</p>
          </div>
        </div>
      )}

      <nav className={cn("flex-1 space-y-1 overflow-y-auto px-3 py-4", mobile && "pt-2")}>
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"
                  : "text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-gray-900 dark:hover:text-white"
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-gray-200 p-4 dark:border-gray-800">
        <div className="rounded-lg bg-indigo-50 p-3 dark:bg-indigo-950">
          <p className="text-xs font-medium text-indigo-800 dark:text-indigo-200">
            نسخه موبایل / PWA
          </p>
          <p className="mt-1 text-xs text-indigo-600 dark:text-indigo-400">
            قابل نصب روی صفحه اصلی گوشی
          </p>
        </div>
      </div>
    </div>
  );

  if (mobile) return content;

  return (
    <aside className="fixed right-0 top-0 z-40 hidden h-screen w-64 border-l border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-950 lg:block">
      {content}
    </aside>
  );
}
