import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Post } from "@/types";
import { platformLabel, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/badge"; // we'll create simple badge

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    published: "bg-emerald-100 text-emerald-700",
    scheduled: "bg-blue-100 text-blue-700",
    draft: "bg-gray-100 text-gray-700",
    failed: "bg-red-100 text-red-700",
  };
  const labels: Record<string, string> = {
    published: "منتشر شده",
    scheduled: "زمان‌بندی شده",
    draft: "پیش‌نویس",
    failed: "ناموفق",
  };
  return (
    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${colors[status] || colors.draft}`}>
      {labels[status] || status}
    </span>
  );
}

export default function RecentPosts({ posts }: { posts: Post[] }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>پست‌های اخیر</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {posts.slice(0, 4).map((post) => (
          <div
            key={post.id}
            className="flex items-start gap-3 rounded-lg border border-gray-100 p-3 transition hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-900"
          >
            <div className="flex-1 min-w-0">
              <p className="line-clamp-2 text-sm text-gray-800 dark:text-gray-200">
                {post.content}
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <StatusBadge status={post.status} />
                {post.platforms.map((p) => (
                  <span
                    key={p}
                    className="rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                  >
                    {platformLabel(p)}
                  </span>
                ))}
                {post.scheduledAt && (
                  <span className="text-xs text-gray-400">
                    {formatDate(post.scheduledAt)}
                  </span>
                )}
              </div>
            </div>
            {post.engagement && (
              <div className="text-left text-xs text-gray-500 whitespace-nowrap">
                <div>❤️ {post.engagement.likes}</div>
                <div>💬 {post.engagement.comments}</div>
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
