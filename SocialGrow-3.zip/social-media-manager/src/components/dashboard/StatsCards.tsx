import { Card, CardContent } from "@/components/ui/card";
import { formatNumber } from "@/lib/utils";
import { Users, TrendingUp, Heart, FileText } from "lucide-react";
import { AnalyticsOverview } from "@/types";

export default function StatsCards({ data }: { data: AnalyticsOverview }) {
  const stats = [
    {
      label: "کل فالوورها",
      value: formatNumber(data.totalFollowers),
      change: `+${data.followerGrowth}%`,
      icon: Users,
      color: "text-indigo-600 bg-indigo-50",
    },
    {
      label: "نرخ تعامل",
      value: `${data.engagementRate}%`,
      change: "+0.4%",
      icon: Heart,
      color: "text-pink-600 bg-pink-50",
    },
    {
      label: "تعامل این ماه",
      value: formatNumber(data.totalEngagement),
      change: "+12%",
      icon: TrendingUp,
      color: "text-emerald-600 bg-emerald-50",
    },
    {
      label: "پست این هفته",
      value: data.postsThisWeek.toString(),
      change: "۷ پست",
      icon: FileText,
      color: "text-amber-600 bg-amber-50",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.label}>
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">
                    {stat.value}
                  </p>
                  <p className="mt-1 text-xs text-emerald-600">{stat.change}</p>
                </div>
                <div className={`rounded-xl p-3 ${stat.color}`}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
