import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { platformLabel, formatNumber, platformColor } from "@/lib/utils";
import { PlatformStats } from "@/types";

export default function PlatformOverview({ stats }: { stats: PlatformStats[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>عملکرد پلتفرم‌ها</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {stats.map((item) => (
          <div key={item.platform} className="flex items-center gap-4">
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-lg text-white text-xs font-bold ${platformColor(item.platform)}`}
            >
              {item.platform.slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="font-medium text-gray-900 dark:text-white">
                  {platformLabel(item.platform)}
                </span>
                <span className="text-sm text-gray-500">
                  {formatNumber(item.followers)} فالوور
                </span>
              </div>
              <div className="mt-1.5 flex items-center gap-3 text-xs text-gray-500">
                <span>نرخ تعامل: {item.engagementRate}%</span>
                <span>•</span>
                <span>{item.posts} پست</span>
                <span>•</span>
                <span className="text-emerald-600">+{item.growth}%</span>
              </div>
              {/* Progress bar */}
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
                <div
                  className="h-full rounded-full bg-indigo-500"
                  style={{ width: `${Math.min(item.engagementRate * 10, 100)}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
