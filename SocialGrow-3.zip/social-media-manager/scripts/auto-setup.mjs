#!/usr/bin/env node
/**
 * یک دستور برای همه: node scripts/auto-setup.mjs
 * یا: npm run go
 */
import { execSync } from "child_process";
import fs from "fs";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, "..");
process.chdir(root);

function run(cmd) {
  console.log("\n→", cmd);
  execSync(cmd, { stdio: "inherit", shell: true });
}

console.log("==================================");
console.log("  SocialGrow — نصب کاملاً خودکار");
console.log("==================================");

if (!fs.existsSync(".env.local") && !fs.existsSync(".env")) {
  fs.copyFileSync(".env.example", ".env.local");
  const secret = crypto.randomBytes(32).toString("base64");
  let env = fs.readFileSync(".env.local", "utf8");
  env = env.replace("change-me-with-openssl-rand-base64-32", secret);
  fs.writeFileSync(".env.local", env);
  console.log("✓ .env.local ساخته شد");
} else {
  console.log("✓ فایل محیط موجود است");
}

run("npm install --legacy-peer-deps");
run("npx prisma generate");
run("npx prisma db push");
try {
  run("npx tsx prisma/seed.ts");
} catch {
  console.log("⚠ seed رد شد (اختیاری)");
}

console.log("\n==================================");
console.log("  ✅ تمام — در حال اجرای برنامه");
console.log("  مرورگر: http://localhost:3000");
console.log("==================================\n");

run("npx next dev -H 0.0.0.0 -p 3000");
