@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==================================
echo   SocialGrow - nasb khodkar
echo ==================================

where node >nul 2>&1
if errorlevel 1 (
  echo Node.js nasb nist. Az nodejs.org nasb konid.
  pause
  exit /b 1
)

if not exist .env.local (
  if not exist .env (
    echo Sakhte .env.local ...
    copy .env.example .env.local >nul
  )
)

echo Nasb package-ha...
call npm install --legacy-peer-deps

echo Database...
call npx prisma generate
call npx prisma db push
call npx tsx prisma/seed.ts

echo.
echo ==================================
echo   Nasb tamam shod
echo ==================================
echo Baraye ejra: npm run dev
echo Browser: http://localhost:3000
echo.
if "%1"=="start" (
  call npm run dev -- -H 0.0.0.0
) else (
  pause
)
