import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // پاک کردن داده‌های قبلی (فقط برای توسعه)
  await prisma.comment.deleteMany();
  await prisma.postAccount.deleteMany();
  await prisma.post.deleteMany();
  await prisma.socialAccount.deleteMany();
  await prisma.user.deleteMany();
  await prisma.media.deleteMany();

  // کاربر نمونه
  const user = await prisma.user.create({
    data: {
      name: "مدیر برند",
      email: "admin@socialgrow.local",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=admin",
    },
  });

  // اکانت‌ها
  const accounts = await Promise.all([
    prisma.socialAccount.create({
      data: {
        platform: "instagram",
        username: "brand_official",
        displayName: "برند رسمی",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=brand",
        followers: 28450,
        connected: true,
        userId: user.id,
      },
    }),
    prisma.socialAccount.create({
      data: {
        platform: "twitter",
        username: "brand_x",
        displayName: "Brand on X",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=twitter",
        followers: 15200,
        connected: true,
        userId: user.id,
      },
    }),
    prisma.socialAccount.create({
      data: {
        platform: "linkedin",
        username: "brand-company",
        displayName: "Brand Company",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=linkedin",
        followers: 8750,
        connected: true,
        userId: user.id,
      },
    }),
    prisma.socialAccount.create({
      data: {
        platform: "tiktok",
        username: "brand_tiktok",
        displayName: "Brand TikTok",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=tiktok",
        followers: 42100,
        connected: false,
        userId: user.id,
      },
    }),
    prisma.socialAccount.create({
      data: {
        platform: "youtube",
        username: "BrandOfficialYT",
        displayName: "برند رسمی | YouTube",
        avatarUrl: "https://api.dicebear.com/7.x/avataaars/svg?seed=youtube",
        followers: 18600,
        connected: true,
        userId: user.id,
      },
    }),
  ]);

  // پست‌ها
  const post1 = await prisma.post.create({
    data: {
      content:
        "🚀 محصول جدید ما امروز رونمایی شد! نظراتتون رو برامون بنویسید.\n\n#محصول_جدید #نوآوری #برند",
      status: "published",
      publishedAt: new Date(Date.now() - 3600000 * 5),
      platforms: JSON.stringify(["instagram", "twitter"]),
      engagement: JSON.stringify({ likes: 1240, comments: 89, shares: 45, views: 15200 }),
      userId: user.id,
      accounts: {
        create: [
          { accountId: accounts[0].id },
          { accountId: accounts[1].id },
        ],
      },
    },
  });

  const post2 = await prisma.post.create({
    data: {
      content: "۵ نکته طلایی برای رشد کسب‌وکار در سال ۲۰۲۶ 📈\n\nکدومش براتون مفیدتره؟",
      status: "scheduled",
      scheduledAt: new Date(Date.now() + 3600000 * 24),
      platforms: JSON.stringify(["linkedin", "twitter"]),
      userId: user.id,
      accounts: {
        create: [
          { accountId: accounts[2].id },
          { accountId: accounts[1].id },
        ],
      },
    },
  });

  await prisma.post.create({
    data: {
      content: "ویدیو پشت صحنه تیم ما 🎥\nچطور یک ایده به محصول تبدیل می‌شه؟",
      status: "draft",
      platforms: JSON.stringify(["tiktok", "instagram"]),
      userId: user.id,
    },
  });

  // کامنت‌ها
  await prisma.comment.createMany({
    data: [
      {
        platform: "instagram",
        author: "user_ali",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ali",
        content: "عالی بود! کی موجود می‌شه؟",
        replied: false,
        postId: post1.id,
        userId: user.id,
        createdAt: new Date(Date.now() - 3600000 * 2),
      },
      {
        platform: "twitter",
        author: "sara_dev",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara",
        content: "خیلی منتظر این محصول بودم 🔥",
        replied: true,
        replyContent: "ممنون از همراهیتون سارا جان! به زودی خبر می‌دیم 💙",
        repliedAt: new Date(Date.now() - 3000000),
        postId: post1.id,
        userId: user.id,
        createdAt: new Date(Date.now() - 3600000),
      },
      {
        platform: "instagram",
        author: "reza_photo",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=reza",
        content: "کیفیت عکس‌ها فوق‌العاده است",
        replied: false,
        postId: post1.id,
        userId: user.id,
        createdAt: new Date(Date.now() - 1800000),
      },
      {
        platform: "linkedin",
        author: "BusinessPro",
        authorAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=biz",
        content: "نکته سوم واقعاً کلیدی بود. ممنون از اشتراک‌گذاری.",
        replied: false,
        postId: post2.id,
        userId: user.id,
        createdAt: new Date(Date.now() - 7200000),
      },
    ],
  });

  console.log("✅ Seed completed successfully!");
  console.log(`   User: ${user.email}`);
  console.log(`   Accounts: ${accounts.length}`);
  console.log(`   Posts & Comments created`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
