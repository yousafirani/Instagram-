# اجرای SocialGrow روی گوشی (درست و پایدار)

هدف: از گوشی استفاده کنید؛ **سرور را خودتان روشن نگه ندارید**.

## ۱) یک‌بار روی کامپیوتر یا Codespace

```bash
unzip SocialGrow.zip
cd social-media-manager
npm install --legacy-peer-deps
```

کد را در GitHub بگذارید (مخزن جدید → Upload یا git push).

## ۲) دیتابیس ابری رایگان

SQLite روی Vercel ماندگار نیست. یکی از این‌ها:

- [Neon](https://neon.tech) — Postgres رایگان
- [Supabase](https://supabase.com) — Postgres رایگان

`DATABASE_URL` را کپی کنید.

در `prisma/schema.prisma` اگر خواستید:

```
provider = "postgresql"
```

سپس:

```bash
npx prisma db push
```

## ۳) Deploy روی Vercel (رایگان)

1. وارد [vercel.com](https://vercel.com) شوید با GitHub
2. Import مخزن
3. Environment Variables:
   - `DATABASE_URL`
   - `AUTH_SECRET`
   - `CRON_SECRET` (اختیاری)
4. Deploy

Cron هر دقیقه `/api/cron/publish` را می‌زند تا پست‌های زمان‌رسیده منتشر شوند — **بدون Redis و بدون گوشی به‌عنوان سرور**.

## ۴) روی گوشی

1. آدرس `https://your-app.vercel.app` را باز کنید
2. منوی مرورگر → **Add to Home Screen / افزودن به صفحه اصلی**
3. مثل اپ باز می‌شود (PWA)

نوار پایین: خانه · پست · کامنت · رشد · بیشتر

## ۵) چه چیزی درست شد در این نسخه

- بدون Redis هم زمان‌بندی نمی‌شکند
- Cron به‌جای Worker روی سرور ابری
- UI موبایل + PWA
- گوشی فقط کلاینت است (درست‌ترین معماری)

## چه چیزی عمداً نیست

- گوشی به‌عنوان سرور ۲۴ ساعته
- دایرکت انبوه به فالوورها
