#!/data/data/com.termux/files/usr/bin/bash
# نصب خودکار روی Termux (اندروید)
set -e
cd "$(dirname "$0")"

echo "=== SocialGrow روی Termux ==="

pkg update -y
pkg install -y nodejs git openssl 2>/dev/null || true

if [ ! -f .env.local ]; then
  cp .env.example .env.local
  SECRET=$(openssl rand -base64 24 2>/dev/null || echo "termux-$RANDOM")
  sed -i "s|change-me-with-openssl-rand-base64-32|$SECRET|g" .env.local
fi

npm install --legacy-peer-deps
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts 2>/dev/null || true

echo ""
echo "OK. Ejra: npm run dev -- -H 0.0.0.0"
echo "Browser: http://127.0.0.1:3000"
echo ""
npm run dev -- -H 0.0.0.0
