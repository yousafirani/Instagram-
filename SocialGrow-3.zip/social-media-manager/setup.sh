#!/usr/bin/env bash
# نصب و راه‌اندازی خودکار SocialGrow
set -e
cd "$(dirname "$0")"

echo "=================================="
echo "  SocialGrow — نصب خودکار"
echo "=================================="

# بررسی Node
if ! command -v node >/dev/null 2>&1; then
  echo "❌ Node.js نصب نیست. از https://nodejs.org نصب کنید."
  exit 1
fi
echo "✓ Node $(node -v)"

# فایل محیط
if [ ! -f .env.local ] && [ ! -f .env ]; then
  echo "→ ساخت .env.local ..."
  cp .env.example .env.local 2>/dev/null || true
  # AUTH_SECRET تصادفی
  if command -v openssl >/dev/null 2>&1; then
    SECRET=$(openssl rand -base64 32 | tr -d '\n')
  else
    SECRET="socialgrow-$(date +%s)-$RANDOM-change-me"
  fi
  if [ -f .env.local ]; then
    if grep -q 'change-me-with-openssl' .env.local 2>/dev/null; then
      sed -i.bak "s|change-me-with-openssl-rand-base64-32|$SECRET|g" .env.local 2>/dev/null || \
      sed -i '' "s|change-me-with-openssl-rand-base64-32|$SECRET|g" .env.local 2>/dev/null || true
    fi
  fi
  echo "✓ .env.local آماده شد"
else
  echo "✓ فایل محیط از قبل وجود دارد"
fi

echo "→ نصب پکیج‌ها (ممکن است چند دقیقه طول بکشد)..."
npm install --legacy-peer-deps

echo "→ راه‌اندازی دیتابیس..."
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts 2>/dev/null || echo "⚠ seed اختیاری رد شد (مشکلی نیست)"

echo ""
echo "=================================="
echo "  ✅ نصب تمام شد"
echo "=================================="
echo "برای اجرا:"
echo "  npm run dev"
echo ""
echo "سپس مرورگر: http://localhost:3000"
echo "=================================="

# اگر آرگومان start داده شد، بلافاصله اجرا کن
if [ "$1" = "start" ] || [ "$1" = "--start" ]; then
  echo "→ در حال اجرا..."
  npm run dev -- -H 0.0.0.0
fi
